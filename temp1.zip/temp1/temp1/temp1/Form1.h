#pragma once
#include "dialogx.h"
namespace temp1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
		
		


	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	protected: 
	private: System::Windows::Forms::ToolStripMenuItem^  projectToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  newProjectToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  newProjectWizardToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  saveCurrentProjectToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  openProjectToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  openProjectWizardToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  requirementToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  sensorsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  preferencesToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  constrainsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  viewDisplayToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  runToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  updateToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  reportToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  helpToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  saveAsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  saveProjectWithNewNameToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  projectPropertiesToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  recentProjectsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  exitToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  openToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  aOIFileToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  dEMFileToolStripMenuItem;






	private: System::Windows::Forms::ToolStripMenuItem^  aOIFilesToolStripMenuItem;

	private: System::Windows::Forms::ToolStripMenuItem^  dEMFileToolStripMenuItem1;
	private: System::Windows::Forms::ToolStripMenuItem^  viewFlightPlanToolStripMenuItem1;
	private: System::Windows::Forms::ToolStripMenuItem^  availableToolStripMenuItem2;
	private: System::Windows::Forms::ToolStripMenuItem^  notAvailableToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  viewFlightPlanReportToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  availableToolStripMenuItem3;
	private: System::Windows::Forms::ToolStripMenuItem^  yetToBePreparedToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  minDataDensitypm2ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  toleranceDataDensity3040ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  spacingToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  alongTrackToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  acrossTrackToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  spacingRatioToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  maxPlanimetricErrorToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  maxAltimetricErrorToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  gSDByCameraToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  minEndLap60ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  minSideLap25ToolStripMenuItem;





	private: System::Windows::Forms::ToolStripMenuItem^  constraintsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  displayInitialReportToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  laserScannerToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  gPSSensorToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  iMUSensorToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  cameraSensorToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  aerialVehicleToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  selectFromListToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  customizedToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  maxFlyingHeightToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  minFlyingHeightkmmToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  maxAirSpeedknotskmphToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  minAirSpeedknotskmphToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  maxBankingAngledegreesToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  minBankingAngledegreesToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  cushionPeriodCushionLengthToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  reactionTime4SecondsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  toleranceforHorizentalSlidingToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  designFlightPlanToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  designSessionPlanToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  reDesignSessionToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  reDesignSessionsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  dispalyInitialReportToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  displayFinalReportToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  allReportsInHTMLToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  formatsWithPrintToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  optionsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  helpHTMLToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  helpPDFToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  activateLicenseToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  flightPlanToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  aOIDisplayTabulatedToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  editAOIDataToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  dEMDisplayToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  flightStripsDisplayOnDEMToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  flightLinesDisplayInAirToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  flightMapGraphicsWindowToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  aOIDisplayToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  flightsStripsDisplayToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  flightLinesDisplayToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  flightLinesTabulateedWindowToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  flightLineNoToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  leftEndNameToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  rightEndNameToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  leftEndCoordinatesToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  rightEndCoordinatesToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  turningFromToToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  editToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  detailsOpenAnotherWindowToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  spacingBeToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  swathBToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  overlapetaToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  minFlyingHeight300MToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  aToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  accuracyOfDEMCell10MToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  cellSizeOfDEM30MToolStripMenuItem;


















private: System::Windows::Forms::ToolStripMenuItem^  selectLaserScannerToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  selectFromListToolStripMenuItem1;
private: System::Windows::Forms::ToolStripMenuItem^  customizeLaserScannerToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  maxBaseLineLengthToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  maxPlanimetricErrorToolStripMenuItem1;
private: System::Windows::Forms::ToolStripMenuItem^  maxAltimetricErrorToolStripMenuItem1;
private: System::Windows::Forms::ToolStripMenuItem^  maxBankAngle45DegToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  selectIMUSensorToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  selectFromListToolStripMenuItem2;
private: System::Windows::Forms::ToolStripMenuItem^  customizeIMUScannerToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  selectCameraSensorToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  selectFromListToolStripMenuItem3;
private: System::Windows::Forms::ToolStripMenuItem^  customizeCameraSensorToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  toolStripMenuItem1;
private: System::Windows::Forms::ToolStripMenuItem^  toolStripMenuItem2;
private: System::Windows::Forms::ToolStripMenuItem^  selectLaserScannerToolStripMenuItem1;
private: System::Windows::Forms::ToolStripMenuItem^  selectFromListToolStripMenuItem4;
private: System::Windows::Forms::ToolStripMenuItem^  customizeLaserScannerToolStripMenuItem1;
private: System::Windows::Forms::ToolStripMenuItem^  toolStripMenuItem3;
private: System::Windows::Forms::ToolStripMenuItem^  maxBaseLineLengthToolStripMenuItem1;
private: System::Windows::Forms::ToolStripMenuItem^  maxPlanimetricErrorToolStripMenuItem2;
private: System::Windows::Forms::ToolStripMenuItem^  maxPlanimetricErrorToolStripMenuItem3;
private: System::Windows::Forms::ToolStripMenuItem^  maxBankAngle45DegToolStripMenuItem1;
private: System::Windows::Forms::ToolStripMenuItem^  toolStripMenuItem4;
private: System::Windows::Forms::ToolStripMenuItem^  selectIMUSensorToolStripMenuItem1;
private: System::Windows::Forms::ToolStripMenuItem^  selectFromListToolStripMenuItem5;
private: System::Windows::Forms::ToolStripMenuItem^  customizeIMUSensorToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  toolStripMenuItem5;
private: System::Windows::Forms::ToolStripMenuItem^  selectCameraSensorToolStripMenuItem1;
private: System::Windows::Forms::ToolStripMenuItem^  selectFromListToolStripMenuItem6;
private: System::Windows::Forms::ToolStripMenuItem^  customizeCameraSensorToolStripMenuItem1;
private: System::Windows::Forms::ToolStrip^  toolStrip1;
private: System::Windows::Forms::ToolStripButton^  toolStripButton1;
private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator1;
private: System::Windows::Forms::ToolStripButton^  toolStripButton2;
private: System::Windows::Forms::ToolStripButton^  toolStripButton3;
private: System::Windows::Forms::ToolStripButton^  toolStripButton4;
private: System::Windows::Forms::ToolStripButton^  toolStripButton5;
private: System::Windows::Forms::ToolStripComboBox^  toolStripComboBox1;
private: System::Windows::Forms::ToolStripButton^  toolStripButton6;
private: System::Windows::Forms::ToolStripComboBox^  toolStripComboBox2;
private: System::Windows::Forms::ToolStripButton^  toolStripButton7;
private: System::Windows::Forms::ToolStripComboBox^  toolStripComboBox3;
private: System::Windows::Forms::ToolStripButton^  toolStripButton8;



























	protected: 



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->projectToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->newProjectToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->newProjectWizardToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aOIFilesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->dEMFileToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->accuracyOfDEMCell10MToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->cellSizeOfDEM30MToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->viewFlightPlanToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->availableToolStripMenuItem2 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->notAvailableToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->viewFlightPlanReportToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->availableToolStripMenuItem3 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->yetToBePreparedToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->dEMFileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->minDataDensitypm2ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toleranceDataDensity3040ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->spacingToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->alongTrackToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->acrossTrackToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->spacingRatioToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxPlanimetricErrorToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxAltimetricErrorToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->gSDByCameraToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->minEndLap60ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->minSideLap25ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripMenuItem2 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectLaserScannerToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectFromListToolStripMenuItem4 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->customizeLaserScannerToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripMenuItem3 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxBaseLineLengthToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxPlanimetricErrorToolStripMenuItem2 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxPlanimetricErrorToolStripMenuItem3 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxBankAngle45DegToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripMenuItem4 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectIMUSensorToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectFromListToolStripMenuItem5 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->customizeIMUSensorToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripMenuItem5 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectCameraSensorToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectFromListToolStripMenuItem6 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->customizeCameraSensorToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aOIFileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->constraintsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->displayInitialReportToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saveCurrentProjectToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openProjectToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openProjectWizardToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saveAsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saveProjectWithNewNameToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->projectPropertiesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->recentProjectsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->exitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->requirementToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->sensorsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->laserScannerToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectLaserScannerToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectFromListToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->customizeLaserScannerToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->gPSSensorToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxBaseLineLengthToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxPlanimetricErrorToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxAltimetricErrorToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxBankAngle45DegToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->iMUSensorToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectIMUSensorToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectFromListToolStripMenuItem2 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->customizeIMUScannerToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->cameraSensorToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectCameraSensorToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectFromListToolStripMenuItem3 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->customizeCameraSensorToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->preferencesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aerialVehicleToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->selectFromListToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->customizedToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxFlyingHeightToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->minFlyingHeightkmmToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxAirSpeedknotskmphToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->minAirSpeedknotskmphToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->maxBankingAngledegreesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->minBankingAngledegreesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->cushionPeriodCushionLengthToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->reactionTime4SecondsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toleranceforHorizentalSlidingToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->constrainsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->minFlyingHeight300MToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->viewDisplayToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->flightPlanToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aOIDisplayTabulatedToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->editAOIDataToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->dEMDisplayToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->flightStripsDisplayOnDEMToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->flightLinesDisplayInAirToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->flightMapGraphicsWindowToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aOIDisplayToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->flightsStripsDisplayToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->flightLinesDisplayToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->flightLinesTabulateedWindowToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->flightLineNoToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->leftEndNameToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->rightEndNameToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->leftEndCoordinatesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->rightEndCoordinatesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->turningFromToToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->editToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->detailsOpenAnotherWindowToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->spacingBeToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->swathBToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->overlapetaToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->runToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->designFlightPlanToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->designSessionPlanToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->reDesignSessionToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->updateToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->reDesignSessionsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->reportToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->dispalyInitialReportToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->displayFinalReportToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->allReportsInHTMLToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->formatsWithPrintToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->optionsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->helpToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->helpHTMLToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->helpPDFToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->activateLicenseToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStrip1 = (gcnew System::Windows::Forms::ToolStrip());
			this->toolStripButton1 = (gcnew System::Windows::Forms::ToolStripButton());
			this->toolStripSeparator1 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->toolStripButton2 = (gcnew System::Windows::Forms::ToolStripButton());
			this->toolStripButton3 = (gcnew System::Windows::Forms::ToolStripButton());
			this->toolStripButton4 = (gcnew System::Windows::Forms::ToolStripButton());
			this->toolStripButton5 = (gcnew System::Windows::Forms::ToolStripButton());
			this->toolStripComboBox1 = (gcnew System::Windows::Forms::ToolStripComboBox());
			this->toolStripButton6 = (gcnew System::Windows::Forms::ToolStripButton());
			this->toolStripComboBox2 = (gcnew System::Windows::Forms::ToolStripComboBox());
			this->toolStripButton7 = (gcnew System::Windows::Forms::ToolStripButton());
			this->toolStripComboBox3 = (gcnew System::Windows::Forms::ToolStripComboBox());
			this->toolStripButton8 = (gcnew System::Windows::Forms::ToolStripButton());
			this->menuStrip1->SuspendLayout();
			this->toolStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(10) {this->projectToolStripMenuItem, 
				this->requirementToolStripMenuItem, this->sensorsToolStripMenuItem, this->preferencesToolStripMenuItem, this->constrainsToolStripMenuItem, 
				this->viewDisplayToolStripMenuItem, this->runToolStripMenuItem, this->updateToolStripMenuItem, this->reportToolStripMenuItem, 
				this->helpToolStripMenuItem});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(1282, 35);
			this->menuStrip1->TabIndex = 0;
			this->menuStrip1->Text = L"menuStrip1";
			this->menuStrip1->MouseEnter += gcnew System::EventHandler(this, &Form1::menuStrip1_MouseEnter);
			// 
			// projectToolStripMenuItem
			// 
			this->projectToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(7) {this->newProjectToolStripMenuItem, 
				this->saveCurrentProjectToolStripMenuItem, this->openProjectToolStripMenuItem, this->saveAsToolStripMenuItem, this->projectPropertiesToolStripMenuItem, 
				this->recentProjectsToolStripMenuItem, this->exitToolStripMenuItem});
			this->projectToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Segoe UI Semilight", 10.2F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->projectToolStripMenuItem->Name = L"projectToolStripMenuItem";
			this->projectToolStripMenuItem->Padding = System::Windows::Forms::Padding(6, 4, 6, 0);
			this->projectToolStripMenuItem->Size = System::Drawing::Size(77, 31);
			this->projectToolStripMenuItem->Text = L"Project";
			this->projectToolStripMenuItem->MouseEnter += gcnew System::EventHandler(this, &Form1::projectToolStripMenuItem_MouseEnter);
			this->projectToolStripMenuItem->MouseLeave += gcnew System::EventHandler(this, &Form1::projectToolStripMenuItem_MouseLeave);
			this->projectToolStripMenuItem->MouseHover += gcnew System::EventHandler(this, &Form1::projectToolStripMenuItem_MouseHover);
			// 
			// newProjectToolStripMenuItem
			// 
			this->newProjectToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->newProjectWizardToolStripMenuItem});
			this->newProjectToolStripMenuItem->Name = L"newProjectToolStripMenuItem";
			this->newProjectToolStripMenuItem->Size = System::Drawing::Size(231, 28);
			this->newProjectToolStripMenuItem->Text = L"New Project";
			// 
			// newProjectWizardToolStripMenuItem
			// 
			this->newProjectWizardToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(6) {this->openToolStripMenuItem, 
				this->dEMFileToolStripMenuItem, this->toolStripMenuItem1, this->aOIFileToolStripMenuItem, this->constraintsToolStripMenuItem, 
				this->displayInitialReportToolStripMenuItem});
			this->newProjectWizardToolStripMenuItem->Name = L"newProjectWizardToolStripMenuItem";
			this->newProjectWizardToolStripMenuItem->Size = System::Drawing::Size(227, 28);
			this->newProjectWizardToolStripMenuItem->Text = L"New Project Wizard";
			// 
			// openToolStripMenuItem
			// 
			this->openToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->aOIFilesToolStripMenuItem, 
				this->dEMFileToolStripMenuItem1, this->viewFlightPlanToolStripMenuItem1, this->viewFlightPlanReportToolStripMenuItem});
			this->openToolStripMenuItem->Name = L"openToolStripMenuItem";
			this->openToolStripMenuItem->Size = System::Drawing::Size(233, 28);
			this->openToolStripMenuItem->Text = L"Open";
			// 
			// aOIFilesToolStripMenuItem
			// 
			this->aOIFilesToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->aToolStripMenuItem});
			this->aOIFilesToolStripMenuItem->Name = L"aOIFilesToolStripMenuItem";
			this->aOIFilesToolStripMenuItem->Size = System::Drawing::Size(255, 28);
			this->aOIFilesToolStripMenuItem->Text = L"AOI File";
			// 
			// aToolStripMenuItem
			// 
			this->aToolStripMenuItem->Name = L"aToolStripMenuItem";
			this->aToolStripMenuItem->Size = System::Drawing::Size(297, 28);
			this->aToolStripMenuItem->Text = L"Accuracy of AOI Data (10 cm)";
			// 
			// dEMFileToolStripMenuItem1
			// 
			this->dEMFileToolStripMenuItem1->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->accuracyOfDEMCell10MToolStripMenuItem, 
				this->cellSizeOfDEM30MToolStripMenuItem});
			this->dEMFileToolStripMenuItem1->Name = L"dEMFileToolStripMenuItem1";
			this->dEMFileToolStripMenuItem1->Size = System::Drawing::Size(255, 28);
			this->dEMFileToolStripMenuItem1->Text = L"DEM File";
			// 
			// accuracyOfDEMCell10MToolStripMenuItem
			// 
			this->accuracyOfDEMCell10MToolStripMenuItem->Name = L"accuracyOfDEMCell10MToolStripMenuItem";
			this->accuracyOfDEMCell10MToolStripMenuItem->Size = System::Drawing::Size(290, 28);
			this->accuracyOfDEMCell10MToolStripMenuItem->Text = L"Accuracy of DEM Cell (10 m)";
			// 
			// cellSizeOfDEM30MToolStripMenuItem
			// 
			this->cellSizeOfDEM30MToolStripMenuItem->Name = L"cellSizeOfDEM30MToolStripMenuItem";
			this->cellSizeOfDEM30MToolStripMenuItem->Size = System::Drawing::Size(290, 28);
			this->cellSizeOfDEM30MToolStripMenuItem->Text = L"Cell Size of DEM (30 m)";
			// 
			// viewFlightPlanToolStripMenuItem1
			// 
			this->viewFlightPlanToolStripMenuItem1->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->availableToolStripMenuItem2, 
				this->notAvailableToolStripMenuItem});
			this->viewFlightPlanToolStripMenuItem1->Name = L"viewFlightPlanToolStripMenuItem1";
			this->viewFlightPlanToolStripMenuItem1->Size = System::Drawing::Size(255, 28);
			this->viewFlightPlanToolStripMenuItem1->Text = L"View: Flight Plan";
			// 
			// availableToolStripMenuItem2
			// 
			this->availableToolStripMenuItem2->CheckOnClick = true;
			this->availableToolStripMenuItem2->Name = L"availableToolStripMenuItem2";
			this->availableToolStripMenuItem2->Size = System::Drawing::Size(180, 28);
			this->availableToolStripMenuItem2->Text = L"Available";
			// 
			// notAvailableToolStripMenuItem
			// 
			this->notAvailableToolStripMenuItem->CheckOnClick = true;
			this->notAvailableToolStripMenuItem->Name = L"notAvailableToolStripMenuItem";
			this->notAvailableToolStripMenuItem->Size = System::Drawing::Size(180, 28);
			this->notAvailableToolStripMenuItem->Text = L"Not Available";
			// 
			// viewFlightPlanReportToolStripMenuItem
			// 
			this->viewFlightPlanReportToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->availableToolStripMenuItem3, 
				this->yetToBePreparedToolStripMenuItem});
			this->viewFlightPlanReportToolStripMenuItem->Name = L"viewFlightPlanReportToolStripMenuItem";
			this->viewFlightPlanReportToolStripMenuItem->Size = System::Drawing::Size(255, 28);
			this->viewFlightPlanReportToolStripMenuItem->Text = L"View: Flight Plan Report";
			// 
			// availableToolStripMenuItem3
			// 
			this->availableToolStripMenuItem3->Name = L"availableToolStripMenuItem3";
			this->availableToolStripMenuItem3->Size = System::Drawing::Size(220, 28);
			this->availableToolStripMenuItem3->Text = L"Available";
			// 
			// yetToBePreparedToolStripMenuItem
			// 
			this->yetToBePreparedToolStripMenuItem->Name = L"yetToBePreparedToolStripMenuItem";
			this->yetToBePreparedToolStripMenuItem->Size = System::Drawing::Size(220, 28);
			this->yetToBePreparedToolStripMenuItem->Text = L"Yet to be prepared";
			// 
			// dEMFileToolStripMenuItem
			// 
			this->dEMFileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(9) {this->minDataDensitypm2ToolStripMenuItem, 
				this->toleranceDataDensity3040ToolStripMenuItem, this->spacingToolStripMenuItem, this->spacingRatioToolStripMenuItem, this->maxPlanimetricErrorToolStripMenuItem, 
				this->maxAltimetricErrorToolStripMenuItem, this->gSDByCameraToolStripMenuItem, this->minEndLap60ToolStripMenuItem, this->minSideLap25ToolStripMenuItem});
			this->dEMFileToolStripMenuItem->Name = L"dEMFileToolStripMenuItem";
			this->dEMFileToolStripMenuItem->Size = System::Drawing::Size(233, 28);
			this->dEMFileToolStripMenuItem->Text = L"Project Requirement";
			// 
			// minDataDensitypm2ToolStripMenuItem
			// 
			this->minDataDensitypm2ToolStripMenuItem->Name = L"minDataDensitypm2ToolStripMenuItem";
			this->minDataDensitypm2ToolStripMenuItem->Size = System::Drawing::Size(322, 28);
			this->minDataDensitypm2ToolStripMenuItem->Text = L"Min Data Density (p/m2)";
			// 
			// toleranceDataDensity3040ToolStripMenuItem
			// 
			this->toleranceDataDensity3040ToolStripMenuItem->Name = L"toleranceDataDensity3040ToolStripMenuItem";
			this->toleranceDataDensity3040ToolStripMenuItem->Size = System::Drawing::Size(322, 28);
			this->toleranceDataDensity3040ToolStripMenuItem->Text = L"Tolerance Data Density (30-40%)";
			// 
			// spacingToolStripMenuItem
			// 
			this->spacingToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->alongTrackToolStripMenuItem, 
				this->acrossTrackToolStripMenuItem});
			this->spacingToolStripMenuItem->Name = L"spacingToolStripMenuItem";
			this->spacingToolStripMenuItem->Size = System::Drawing::Size(322, 28);
			this->spacingToolStripMenuItem->Text = L"Spacing ";
			// 
			// alongTrackToolStripMenuItem
			// 
			this->alongTrackToolStripMenuItem->Name = L"alongTrackToolStripMenuItem";
			this->alongTrackToolStripMenuItem->Size = System::Drawing::Size(173, 28);
			this->alongTrackToolStripMenuItem->Text = L"Along Track";
			// 
			// acrossTrackToolStripMenuItem
			// 
			this->acrossTrackToolStripMenuItem->Name = L"acrossTrackToolStripMenuItem";
			this->acrossTrackToolStripMenuItem->Size = System::Drawing::Size(173, 28);
			this->acrossTrackToolStripMenuItem->Text = L"Across Track";
			// 
			// spacingRatioToolStripMenuItem
			// 
			this->spacingRatioToolStripMenuItem->Name = L"spacingRatioToolStripMenuItem";
			this->spacingRatioToolStripMenuItem->Size = System::Drawing::Size(322, 28);
			this->spacingRatioToolStripMenuItem->Text = L"Spacing Ratio";
			// 
			// maxPlanimetricErrorToolStripMenuItem
			// 
			this->maxPlanimetricErrorToolStripMenuItem->Name = L"maxPlanimetricErrorToolStripMenuItem";
			this->maxPlanimetricErrorToolStripMenuItem->Size = System::Drawing::Size(322, 28);
			this->maxPlanimetricErrorToolStripMenuItem->Text = L"Max Planimetric Error (cm)";
			// 
			// maxAltimetricErrorToolStripMenuItem
			// 
			this->maxAltimetricErrorToolStripMenuItem->Name = L"maxAltimetricErrorToolStripMenuItem";
			this->maxAltimetricErrorToolStripMenuItem->Size = System::Drawing::Size(322, 28);
			this->maxAltimetricErrorToolStripMenuItem->Text = L"Max Altimetric Error (cm)";
			// 
			// gSDByCameraToolStripMenuItem
			// 
			this->gSDByCameraToolStripMenuItem->Name = L"gSDByCameraToolStripMenuItem";
			this->gSDByCameraToolStripMenuItem->Size = System::Drawing::Size(322, 28);
			this->gSDByCameraToolStripMenuItem->Text = L"GSD By Camera";
			// 
			// minEndLap60ToolStripMenuItem
			// 
			this->minEndLap60ToolStripMenuItem->Name = L"minEndLap60ToolStripMenuItem";
			this->minEndLap60ToolStripMenuItem->Size = System::Drawing::Size(322, 28);
			this->minEndLap60ToolStripMenuItem->Text = L"Min End Lap (60%)";
			// 
			// minSideLap25ToolStripMenuItem
			// 
			this->minSideLap25ToolStripMenuItem->Name = L"minSideLap25ToolStripMenuItem";
			this->minSideLap25ToolStripMenuItem->Size = System::Drawing::Size(322, 28);
			this->minSideLap25ToolStripMenuItem->Text = L"Min Side Lap (25%)";
			// 
			// toolStripMenuItem1
			// 
			this->toolStripMenuItem1->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->toolStripMenuItem2, 
				this->toolStripMenuItem3, this->toolStripMenuItem4, this->toolStripMenuItem5});
			this->toolStripMenuItem1->Name = L"toolStripMenuItem1";
			this->toolStripMenuItem1->Size = System::Drawing::Size(233, 28);
			this->toolStripMenuItem1->Text = L"Sensors";
			// 
			// toolStripMenuItem2
			// 
			this->toolStripMenuItem2->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->selectLaserScannerToolStripMenuItem1, 
				this->customizeLaserScannerToolStripMenuItem1});
			this->toolStripMenuItem2->Name = L"toolStripMenuItem2";
			this->toolStripMenuItem2->Size = System::Drawing::Size(193, 28);
			this->toolStripMenuItem2->Text = L"Laser Scanner";
			// 
			// selectLaserScannerToolStripMenuItem1
			// 
			this->selectLaserScannerToolStripMenuItem1->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->selectFromListToolStripMenuItem4});
			this->selectLaserScannerToolStripMenuItem1->Name = L"selectLaserScannerToolStripMenuItem1";
			this->selectLaserScannerToolStripMenuItem1->Size = System::Drawing::Size(265, 28);
			this->selectLaserScannerToolStripMenuItem1->Text = L"Select Laser Scanner";
			// 
			// selectFromListToolStripMenuItem4
			// 
			this->selectFromListToolStripMenuItem4->Name = L"selectFromListToolStripMenuItem4";
			this->selectFromListToolStripMenuItem4->Size = System::Drawing::Size(193, 28);
			this->selectFromListToolStripMenuItem4->Text = L"Select from List";
			// 
			// customizeLaserScannerToolStripMenuItem1
			// 
			this->customizeLaserScannerToolStripMenuItem1->Name = L"customizeLaserScannerToolStripMenuItem1";
			this->customizeLaserScannerToolStripMenuItem1->Size = System::Drawing::Size(265, 28);
			this->customizeLaserScannerToolStripMenuItem1->Text = L"Customize Laser Scanner";
			// 
			// toolStripMenuItem3
			// 
			this->toolStripMenuItem3->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->maxBaseLineLengthToolStripMenuItem1, 
				this->maxPlanimetricErrorToolStripMenuItem2, this->maxPlanimetricErrorToolStripMenuItem3, this->maxBankAngle45DegToolStripMenuItem1});
			this->toolStripMenuItem3->Name = L"toolStripMenuItem3";
			this->toolStripMenuItem3->Size = System::Drawing::Size(193, 28);
			this->toolStripMenuItem3->Text = L"GPS Sensor";
			// 
			// maxBaseLineLengthToolStripMenuItem1
			// 
			this->maxBaseLineLengthToolStripMenuItem1->Name = L"maxBaseLineLengthToolStripMenuItem1";
			this->maxBaseLineLengthToolStripMenuItem1->Size = System::Drawing::Size(266, 28);
			this->maxBaseLineLengthToolStripMenuItem1->Text = L"Max Base Line Length";
			// 
			// maxPlanimetricErrorToolStripMenuItem2
			// 
			this->maxPlanimetricErrorToolStripMenuItem2->Name = L"maxPlanimetricErrorToolStripMenuItem2";
			this->maxPlanimetricErrorToolStripMenuItem2->Size = System::Drawing::Size(266, 28);
			this->maxPlanimetricErrorToolStripMenuItem2->Text = L"Max Planimetric Error";
			// 
			// maxPlanimetricErrorToolStripMenuItem3
			// 
			this->maxPlanimetricErrorToolStripMenuItem3->Name = L"maxPlanimetricErrorToolStripMenuItem3";
			this->maxPlanimetricErrorToolStripMenuItem3->Size = System::Drawing::Size(266, 28);
			this->maxPlanimetricErrorToolStripMenuItem3->Text = L"Max Planimetric Error";
			// 
			// maxBankAngle45DegToolStripMenuItem1
			// 
			this->maxBankAngle45DegToolStripMenuItem1->Name = L"maxBankAngle45DegToolStripMenuItem1";
			this->maxBankAngle45DegToolStripMenuItem1->Size = System::Drawing::Size(266, 28);
			this->maxBankAngle45DegToolStripMenuItem1->Text = L"Max Bank Angle (45 deg)";
			// 
			// toolStripMenuItem4
			// 
			this->toolStripMenuItem4->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->selectIMUSensorToolStripMenuItem1, 
				this->customizeIMUSensorToolStripMenuItem});
			this->toolStripMenuItem4->Name = L"toolStripMenuItem4";
			this->toolStripMenuItem4->Size = System::Drawing::Size(193, 28);
			this->toolStripMenuItem4->Text = L"IMU Sensor";
			// 
			// selectIMUSensorToolStripMenuItem1
			// 
			this->selectIMUSensorToolStripMenuItem1->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->selectFromListToolStripMenuItem5});
			this->selectIMUSensorToolStripMenuItem1->Name = L"selectIMUSensorToolStripMenuItem1";
			this->selectIMUSensorToolStripMenuItem1->Size = System::Drawing::Size(247, 28);
			this->selectIMUSensorToolStripMenuItem1->Text = L"Select IMU Sensor";
			// 
			// selectFromListToolStripMenuItem5
			// 
			this->selectFromListToolStripMenuItem5->Name = L"selectFromListToolStripMenuItem5";
			this->selectFromListToolStripMenuItem5->Size = System::Drawing::Size(193, 28);
			this->selectFromListToolStripMenuItem5->Text = L"Select from List";
			// 
			// customizeIMUSensorToolStripMenuItem
			// 
			this->customizeIMUSensorToolStripMenuItem->Name = L"customizeIMUSensorToolStripMenuItem";
			this->customizeIMUSensorToolStripMenuItem->Size = System::Drawing::Size(247, 28);
			this->customizeIMUSensorToolStripMenuItem->Text = L"Customize IMU Sensor";
			// 
			// toolStripMenuItem5
			// 
			this->toolStripMenuItem5->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->selectCameraSensorToolStripMenuItem1, 
				this->customizeCameraSensorToolStripMenuItem1});
			this->toolStripMenuItem5->Name = L"toolStripMenuItem5";
			this->toolStripMenuItem5->Size = System::Drawing::Size(193, 28);
			this->toolStripMenuItem5->Text = L"Camera Sensor";
			// 
			// selectCameraSensorToolStripMenuItem1
			// 
			this->selectCameraSensorToolStripMenuItem1->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->selectFromListToolStripMenuItem6});
			this->selectCameraSensorToolStripMenuItem1->Name = L"selectCameraSensorToolStripMenuItem1";
			this->selectCameraSensorToolStripMenuItem1->Size = System::Drawing::Size(275, 28);
			this->selectCameraSensorToolStripMenuItem1->Text = L"Select Camera Sensor";
			// 
			// selectFromListToolStripMenuItem6
			// 
			this->selectFromListToolStripMenuItem6->Name = L"selectFromListToolStripMenuItem6";
			this->selectFromListToolStripMenuItem6->Size = System::Drawing::Size(193, 28);
			this->selectFromListToolStripMenuItem6->Text = L"Select from List";
			// 
			// customizeCameraSensorToolStripMenuItem1
			// 
			this->customizeCameraSensorToolStripMenuItem1->Name = L"customizeCameraSensorToolStripMenuItem1";
			this->customizeCameraSensorToolStripMenuItem1->Size = System::Drawing::Size(275, 28);
			this->customizeCameraSensorToolStripMenuItem1->Text = L"Customize Camera Sensor";
			// 
			// aOIFileToolStripMenuItem
			// 
			this->aOIFileToolStripMenuItem->Name = L"aOIFileToolStripMenuItem";
			this->aOIFileToolStripMenuItem->Size = System::Drawing::Size(233, 28);
			this->aOIFileToolStripMenuItem->Text = L"Crew Preferences";
			// 
			// constraintsToolStripMenuItem
			// 
			this->constraintsToolStripMenuItem->Name = L"constraintsToolStripMenuItem";
			this->constraintsToolStripMenuItem->Size = System::Drawing::Size(233, 28);
			this->constraintsToolStripMenuItem->Text = L"Constraints";
			// 
			// displayInitialReportToolStripMenuItem
			// 
			this->displayInitialReportToolStripMenuItem->Name = L"displayInitialReportToolStripMenuItem";
			this->displayInitialReportToolStripMenuItem->Size = System::Drawing::Size(233, 28);
			this->displayInitialReportToolStripMenuItem->Text = L"Display Initial Report";
			// 
			// saveCurrentProjectToolStripMenuItem
			// 
			this->saveCurrentProjectToolStripMenuItem->Name = L"saveCurrentProjectToolStripMenuItem";
			this->saveCurrentProjectToolStripMenuItem->Size = System::Drawing::Size(231, 28);
			this->saveCurrentProjectToolStripMenuItem->Text = L"Save Current Project";
			// 
			// openProjectToolStripMenuItem
			// 
			this->openProjectToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->openProjectWizardToolStripMenuItem});
			this->openProjectToolStripMenuItem->Name = L"openProjectToolStripMenuItem";
			this->openProjectToolStripMenuItem->Size = System::Drawing::Size(231, 28);
			this->openProjectToolStripMenuItem->Text = L"Open Project ";
			// 
			// openProjectWizardToolStripMenuItem
			// 
			this->openProjectWizardToolStripMenuItem->Name = L"openProjectWizardToolStripMenuItem";
			this->openProjectWizardToolStripMenuItem->Size = System::Drawing::Size(184, 28);
			this->openProjectWizardToolStripMenuItem->Text = L"Open  Wizard";
			// 
			// saveAsToolStripMenuItem
			// 
			this->saveAsToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->saveProjectWithNewNameToolStripMenuItem});
			this->saveAsToolStripMenuItem->Name = L"saveAsToolStripMenuItem";
			this->saveAsToolStripMenuItem->Size = System::Drawing::Size(231, 28);
			this->saveAsToolStripMenuItem->Text = L"Save as";
			// 
			// saveProjectWithNewNameToolStripMenuItem
			// 
			this->saveProjectWithNewNameToolStripMenuItem->Name = L"saveProjectWithNewNameToolStripMenuItem";
			this->saveProjectWithNewNameToolStripMenuItem->Size = System::Drawing::Size(171, 28);
			this->saveProjectWithNewNameToolStripMenuItem->Text = L"Save as new";
			this->saveProjectWithNewNameToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveProjectWithNewNameToolStripMenuItem_Click);
			// 
			// projectPropertiesToolStripMenuItem
			// 
			this->projectPropertiesToolStripMenuItem->Name = L"projectPropertiesToolStripMenuItem";
			this->projectPropertiesToolStripMenuItem->Size = System::Drawing::Size(231, 28);
			this->projectPropertiesToolStripMenuItem->Text = L"Project Properties";
			// 
			// recentProjectsToolStripMenuItem
			// 
			this->recentProjectsToolStripMenuItem->Name = L"recentProjectsToolStripMenuItem";
			this->recentProjectsToolStripMenuItem->Size = System::Drawing::Size(231, 28);
			this->recentProjectsToolStripMenuItem->Text = L"Recent Projects";
			// 
			// exitToolStripMenuItem
			// 
			this->exitToolStripMenuItem->Name = L"exitToolStripMenuItem";
			this->exitToolStripMenuItem->Size = System::Drawing::Size(231, 28);
			this->exitToolStripMenuItem->Text = L"Exit";
			// 
			// requirementToolStripMenuItem
			// 
			this->requirementToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Segoe UI Semilight", 10.2F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->requirementToolStripMenuItem->Name = L"requirementToolStripMenuItem";
			this->requirementToolStripMenuItem->Padding = System::Windows::Forms::Padding(6, 4, 6, 0);
			this->requirementToolStripMenuItem->Size = System::Drawing::Size(120, 31);
			this->requirementToolStripMenuItem->Text = L"Requirement";
			// 
			// sensorsToolStripMenuItem
			// 
			this->sensorsToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->laserScannerToolStripMenuItem, 
				this->gPSSensorToolStripMenuItem, this->iMUSensorToolStripMenuItem, this->cameraSensorToolStripMenuItem});
			this->sensorsToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Segoe UI Semilight", 10.2F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->sensorsToolStripMenuItem->Name = L"sensorsToolStripMenuItem";
			this->sensorsToolStripMenuItem->Padding = System::Windows::Forms::Padding(6, 4, 6, 0);
			this->sensorsToolStripMenuItem->Size = System::Drawing::Size(83, 31);
			this->sensorsToolStripMenuItem->Text = L"Sensors";
			// 
			// laserScannerToolStripMenuItem
			// 
			this->laserScannerToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->selectLaserScannerToolStripMenuItem, 
				this->customizeLaserScannerToolStripMenuItem});
			this->laserScannerToolStripMenuItem->Name = L"laserScannerToolStripMenuItem";
			this->laserScannerToolStripMenuItem->Size = System::Drawing::Size(193, 28);
			this->laserScannerToolStripMenuItem->Text = L"Laser Scanner";
			// 
			// selectLaserScannerToolStripMenuItem
			// 
			this->selectLaserScannerToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->selectFromListToolStripMenuItem1});
			this->selectLaserScannerToolStripMenuItem->Name = L"selectLaserScannerToolStripMenuItem";
			this->selectLaserScannerToolStripMenuItem->Size = System::Drawing::Size(265, 28);
			this->selectLaserScannerToolStripMenuItem->Text = L"Select Laser Scanner";
			// 
			// selectFromListToolStripMenuItem1
			// 
			this->selectFromListToolStripMenuItem1->Name = L"selectFromListToolStripMenuItem1";
			this->selectFromListToolStripMenuItem1->Size = System::Drawing::Size(196, 28);
			this->selectFromListToolStripMenuItem1->Text = L"Select From List";
			// 
			// customizeLaserScannerToolStripMenuItem
			// 
			this->customizeLaserScannerToolStripMenuItem->Name = L"customizeLaserScannerToolStripMenuItem";
			this->customizeLaserScannerToolStripMenuItem->Size = System::Drawing::Size(265, 28);
			this->customizeLaserScannerToolStripMenuItem->Text = L"Customize Laser Scanner";
			// 
			// gPSSensorToolStripMenuItem
			// 
			this->gPSSensorToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->maxBaseLineLengthToolStripMenuItem, 
				this->maxPlanimetricErrorToolStripMenuItem1, this->maxAltimetricErrorToolStripMenuItem1, this->maxBankAngle45DegToolStripMenuItem});
			this->gPSSensorToolStripMenuItem->Name = L"gPSSensorToolStripMenuItem";
			this->gPSSensorToolStripMenuItem->Size = System::Drawing::Size(193, 28);
			this->gPSSensorToolStripMenuItem->Text = L"GPS Sensor";
			// 
			// maxBaseLineLengthToolStripMenuItem
			// 
			this->maxBaseLineLengthToolStripMenuItem->Name = L"maxBaseLineLengthToolStripMenuItem";
			this->maxBaseLineLengthToolStripMenuItem->Size = System::Drawing::Size(266, 28);
			this->maxBaseLineLengthToolStripMenuItem->Text = L"Max Base Line Length";
			// 
			// maxPlanimetricErrorToolStripMenuItem1
			// 
			this->maxPlanimetricErrorToolStripMenuItem1->Name = L"maxPlanimetricErrorToolStripMenuItem1";
			this->maxPlanimetricErrorToolStripMenuItem1->Size = System::Drawing::Size(266, 28);
			this->maxPlanimetricErrorToolStripMenuItem1->Text = L"Max Planimetric Error";
			// 
			// maxAltimetricErrorToolStripMenuItem1
			// 
			this->maxAltimetricErrorToolStripMenuItem1->Name = L"maxAltimetricErrorToolStripMenuItem1";
			this->maxAltimetricErrorToolStripMenuItem1->Size = System::Drawing::Size(266, 28);
			this->maxAltimetricErrorToolStripMenuItem1->Text = L"Max Altimetric Error";
			// 
			// maxBankAngle45DegToolStripMenuItem
			// 
			this->maxBankAngle45DegToolStripMenuItem->Name = L"maxBankAngle45DegToolStripMenuItem";
			this->maxBankAngle45DegToolStripMenuItem->Size = System::Drawing::Size(266, 28);
			this->maxBankAngle45DegToolStripMenuItem->Text = L"Max Bank Angle (45 deg)";
			// 
			// iMUSensorToolStripMenuItem
			// 
			this->iMUSensorToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->selectIMUSensorToolStripMenuItem, 
				this->customizeIMUScannerToolStripMenuItem});
			this->iMUSensorToolStripMenuItem->Name = L"iMUSensorToolStripMenuItem";
			this->iMUSensorToolStripMenuItem->Size = System::Drawing::Size(193, 28);
			this->iMUSensorToolStripMenuItem->Text = L"IMU Sensor";
			// 
			// selectIMUSensorToolStripMenuItem
			// 
			this->selectIMUSensorToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->selectFromListToolStripMenuItem2});
			this->selectIMUSensorToolStripMenuItem->Name = L"selectIMUSensorToolStripMenuItem";
			this->selectIMUSensorToolStripMenuItem->Size = System::Drawing::Size(247, 28);
			this->selectIMUSensorToolStripMenuItem->Text = L"Select IMU Sensor";
			// 
			// selectFromListToolStripMenuItem2
			// 
			this->selectFromListToolStripMenuItem2->Name = L"selectFromListToolStripMenuItem2";
			this->selectFromListToolStripMenuItem2->Size = System::Drawing::Size(196, 28);
			this->selectFromListToolStripMenuItem2->Text = L"Select From List";
			// 
			// customizeIMUScannerToolStripMenuItem
			// 
			this->customizeIMUScannerToolStripMenuItem->Name = L"customizeIMUScannerToolStripMenuItem";
			this->customizeIMUScannerToolStripMenuItem->Size = System::Drawing::Size(247, 28);
			this->customizeIMUScannerToolStripMenuItem->Text = L"Customize IMU Sensor";
			// 
			// cameraSensorToolStripMenuItem
			// 
			this->cameraSensorToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->selectCameraSensorToolStripMenuItem, 
				this->customizeCameraSensorToolStripMenuItem});
			this->cameraSensorToolStripMenuItem->Name = L"cameraSensorToolStripMenuItem";
			this->cameraSensorToolStripMenuItem->Size = System::Drawing::Size(193, 28);
			this->cameraSensorToolStripMenuItem->Text = L"Camera Sensor";
			// 
			// selectCameraSensorToolStripMenuItem
			// 
			this->selectCameraSensorToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->selectFromListToolStripMenuItem3});
			this->selectCameraSensorToolStripMenuItem->Name = L"selectCameraSensorToolStripMenuItem";
			this->selectCameraSensorToolStripMenuItem->Size = System::Drawing::Size(275, 28);
			this->selectCameraSensorToolStripMenuItem->Text = L"Select Camera Sensor";
			// 
			// selectFromListToolStripMenuItem3
			// 
			this->selectFromListToolStripMenuItem3->Name = L"selectFromListToolStripMenuItem3";
			this->selectFromListToolStripMenuItem3->Size = System::Drawing::Size(196, 28);
			this->selectFromListToolStripMenuItem3->Text = L"Select From List";
			// 
			// customizeCameraSensorToolStripMenuItem
			// 
			this->customizeCameraSensorToolStripMenuItem->Name = L"customizeCameraSensorToolStripMenuItem";
			this->customizeCameraSensorToolStripMenuItem->Size = System::Drawing::Size(275, 28);
			this->customizeCameraSensorToolStripMenuItem->Text = L"Customize Camera Sensor";
			// 
			// preferencesToolStripMenuItem
			// 
			this->preferencesToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(10) {this->aerialVehicleToolStripMenuItem, 
				this->maxFlyingHeightToolStripMenuItem, this->minFlyingHeightkmmToolStripMenuItem, this->maxAirSpeedknotskmphToolStripMenuItem, 
				this->minAirSpeedknotskmphToolStripMenuItem, this->maxBankingAngledegreesToolStripMenuItem, this->minBankingAngledegreesToolStripMenuItem, 
				this->cushionPeriodCushionLengthToolStripMenuItem, this->reactionTime4SecondsToolStripMenuItem, this->toleranceforHorizentalSlidingToolStripMenuItem});
			this->preferencesToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Segoe UI Semilight", 10.2F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->preferencesToolStripMenuItem->Name = L"preferencesToolStripMenuItem";
			this->preferencesToolStripMenuItem->Padding = System::Windows::Forms::Padding(6, 4, 6, 0);
			this->preferencesToolStripMenuItem->Size = System::Drawing::Size(112, 31);
			this->preferencesToolStripMenuItem->Text = L"Preferences";
			this->preferencesToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::preferencesToolStripMenuItem_Click);
			// 
			// aerialVehicleToolStripMenuItem
			// 
			this->aerialVehicleToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->selectFromListToolStripMenuItem, 
				this->customizedToolStripMenuItem});
			this->aerialVehicleToolStripMenuItem->Name = L"aerialVehicleToolStripMenuItem";
			this->aerialVehicleToolStripMenuItem->Size = System::Drawing::Size(321, 28);
			this->aerialVehicleToolStripMenuItem->Text = L"Aerial Vehicle";
			// 
			// selectFromListToolStripMenuItem
			// 
			this->selectFromListToolStripMenuItem->Name = L"selectFromListToolStripMenuItem";
			this->selectFromListToolStripMenuItem->Size = System::Drawing::Size(189, 28);
			this->selectFromListToolStripMenuItem->Text = L"Select from list";
			// 
			// customizedToolStripMenuItem
			// 
			this->customizedToolStripMenuItem->Name = L"customizedToolStripMenuItem";
			this->customizedToolStripMenuItem->Size = System::Drawing::Size(189, 28);
			this->customizedToolStripMenuItem->Text = L"Customized";
			// 
			// maxFlyingHeightToolStripMenuItem
			// 
			this->maxFlyingHeightToolStripMenuItem->Name = L"maxFlyingHeightToolStripMenuItem";
			this->maxFlyingHeightToolStripMenuItem->Size = System::Drawing::Size(321, 28);
			this->maxFlyingHeightToolStripMenuItem->Text = L"Max flying height (km/m)";
			// 
			// minFlyingHeightkmmToolStripMenuItem
			// 
			this->minFlyingHeightkmmToolStripMenuItem->Name = L"minFlyingHeightkmmToolStripMenuItem";
			this->minFlyingHeightkmmToolStripMenuItem->Size = System::Drawing::Size(321, 28);
			this->minFlyingHeightkmmToolStripMenuItem->Text = L"Min flying height (km/m)";
			// 
			// maxAirSpeedknotskmphToolStripMenuItem
			// 
			this->maxAirSpeedknotskmphToolStripMenuItem->Name = L"maxAirSpeedknotskmphToolStripMenuItem";
			this->maxAirSpeedknotskmphToolStripMenuItem->Size = System::Drawing::Size(321, 28);
			this->maxAirSpeedknotskmphToolStripMenuItem->Text = L"Max Air Speed (knots/kmph)";
			// 
			// minAirSpeedknotskmphToolStripMenuItem
			// 
			this->minAirSpeedknotskmphToolStripMenuItem->Name = L"minAirSpeedknotskmphToolStripMenuItem";
			this->minAirSpeedknotskmphToolStripMenuItem->Size = System::Drawing::Size(321, 28);
			this->minAirSpeedknotskmphToolStripMenuItem->Text = L"Min Air Speed (knots/kmph)";
			// 
			// maxBankingAngledegreesToolStripMenuItem
			// 
			this->maxBankingAngledegreesToolStripMenuItem->Name = L"maxBankingAngledegreesToolStripMenuItem";
			this->maxBankingAngledegreesToolStripMenuItem->Size = System::Drawing::Size(321, 28);
			this->maxBankingAngledegreesToolStripMenuItem->Text = L"Max Banking Angle (degrees)";
			// 
			// minBankingAngledegreesToolStripMenuItem
			// 
			this->minBankingAngledegreesToolStripMenuItem->Name = L"minBankingAngledegreesToolStripMenuItem";
			this->minBankingAngledegreesToolStripMenuItem->Size = System::Drawing::Size(321, 28);
			this->minBankingAngledegreesToolStripMenuItem->Text = L"Min Banking Angle (degrees)";
			// 
			// cushionPeriodCushionLengthToolStripMenuItem
			// 
			this->cushionPeriodCushionLengthToolStripMenuItem->Name = L"cushionPeriodCushionLengthToolStripMenuItem";
			this->cushionPeriodCushionLengthToolStripMenuItem->Size = System::Drawing::Size(321, 28);
			this->cushionPeriodCushionLengthToolStripMenuItem->Text = L"Cushion Period / Cushion Length";
			// 
			// reactionTime4SecondsToolStripMenuItem
			// 
			this->reactionTime4SecondsToolStripMenuItem->Name = L"reactionTime4SecondsToolStripMenuItem";
			this->reactionTime4SecondsToolStripMenuItem->Size = System::Drawing::Size(321, 28);
			this->reactionTime4SecondsToolStripMenuItem->Text = L"Reaction Time : 4 Seconds";
			// 
			// toleranceforHorizentalSlidingToolStripMenuItem
			// 
			this->toleranceforHorizentalSlidingToolStripMenuItem->Name = L"toleranceforHorizentalSlidingToolStripMenuItem";
			this->toleranceforHorizentalSlidingToolStripMenuItem->Size = System::Drawing::Size(321, 28);
			this->toleranceforHorizentalSlidingToolStripMenuItem->Text = L"Tolerance (for horizental sliding)";
			// 
			// constrainsToolStripMenuItem
			// 
			this->constrainsToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->minFlyingHeight300MToolStripMenuItem});
			this->constrainsToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Segoe UI Semilight", 10.2F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->constrainsToolStripMenuItem->Name = L"constrainsToolStripMenuItem";
			this->constrainsToolStripMenuItem->Padding = System::Windows::Forms::Padding(6, 4, 6, 0);
			this->constrainsToolStripMenuItem->Size = System::Drawing::Size(103, 31);
			this->constrainsToolStripMenuItem->Text = L"Constrains";
			// 
			// minFlyingHeight300MToolStripMenuItem
			// 
			this->minFlyingHeight300MToolStripMenuItem->Name = L"minFlyingHeight300MToolStripMenuItem";
			this->minFlyingHeight300MToolStripMenuItem->Size = System::Drawing::Size(271, 28);
			this->minFlyingHeight300MToolStripMenuItem->Text = L"Min Flying Height (300 m)";
			// 
			// viewDisplayToolStripMenuItem
			// 
			this->viewDisplayToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->flightPlanToolStripMenuItem, 
				this->flightMapGraphicsWindowToolStripMenuItem, this->flightLinesTabulateedWindowToolStripMenuItem, this->detailsOpenAnotherWindowToolStripMenuItem});
			this->viewDisplayToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Segoe UI Semilight", 10.2F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->viewDisplayToolStripMenuItem->Name = L"viewDisplayToolStripMenuItem";
			this->viewDisplayToolStripMenuItem->Padding = System::Windows::Forms::Padding(6, 4, 6, 0);
			this->viewDisplayToolStripMenuItem->Size = System::Drawing::Size(121, 31);
			this->viewDisplayToolStripMenuItem->Text = L"View/Display";
			// 
			// flightPlanToolStripMenuItem
			// 
			this->flightPlanToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->aOIDisplayTabulatedToolStripMenuItem, 
				this->dEMDisplayToolStripMenuItem, this->flightStripsDisplayOnDEMToolStripMenuItem, this->flightLinesDisplayInAirToolStripMenuItem});
			this->flightPlanToolStripMenuItem->Name = L"flightPlanToolStripMenuItem";
			this->flightPlanToolStripMenuItem->Size = System::Drawing::Size(324, 28);
			this->flightPlanToolStripMenuItem->Text = L"Flight Plan (Graphics Window)";
			// 
			// aOIDisplayTabulatedToolStripMenuItem
			// 
			this->aOIDisplayTabulatedToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->editAOIDataToolStripMenuItem});
			this->aOIDisplayTabulatedToolStripMenuItem->Name = L"aOIDisplayTabulatedToolStripMenuItem";
			this->aOIDisplayTabulatedToolStripMenuItem->Size = System::Drawing::Size(289, 28);
			this->aOIDisplayTabulatedToolStripMenuItem->Text = L"AOI Display (Tabulated)";
			// 
			// editAOIDataToolStripMenuItem
			// 
			this->editAOIDataToolStripMenuItem->Name = L"editAOIDataToolStripMenuItem";
			this->editAOIDataToolStripMenuItem->Size = System::Drawing::Size(181, 28);
			this->editAOIDataToolStripMenuItem->Text = L"Edit AOI Data";
			// 
			// dEMDisplayToolStripMenuItem
			// 
			this->dEMDisplayToolStripMenuItem->Name = L"dEMDisplayToolStripMenuItem";
			this->dEMDisplayToolStripMenuItem->Size = System::Drawing::Size(289, 28);
			this->dEMDisplayToolStripMenuItem->Text = L"DEM Display";
			// 
			// flightStripsDisplayOnDEMToolStripMenuItem
			// 
			this->flightStripsDisplayOnDEMToolStripMenuItem->Name = L"flightStripsDisplayOnDEMToolStripMenuItem";
			this->flightStripsDisplayOnDEMToolStripMenuItem->Size = System::Drawing::Size(289, 28);
			this->flightStripsDisplayOnDEMToolStripMenuItem->Text = L"Flight Strips Display on DEM";
			// 
			// flightLinesDisplayInAirToolStripMenuItem
			// 
			this->flightLinesDisplayInAirToolStripMenuItem->Name = L"flightLinesDisplayInAirToolStripMenuItem";
			this->flightLinesDisplayInAirToolStripMenuItem->Size = System::Drawing::Size(289, 28);
			this->flightLinesDisplayInAirToolStripMenuItem->Text = L"Flight Lines Display in Air";
			// 
			// flightMapGraphicsWindowToolStripMenuItem
			// 
			this->flightMapGraphicsWindowToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->aOIDisplayToolStripMenuItem, 
				this->flightsStripsDisplayToolStripMenuItem, this->flightLinesDisplayToolStripMenuItem});
			this->flightMapGraphicsWindowToolStripMenuItem->Name = L"flightMapGraphicsWindowToolStripMenuItem";
			this->flightMapGraphicsWindowToolStripMenuItem->Size = System::Drawing::Size(324, 28);
			this->flightMapGraphicsWindowToolStripMenuItem->Text = L"Flight Map(Graphics Window)";
			// 
			// aOIDisplayToolStripMenuItem
			// 
			this->aOIDisplayToolStripMenuItem->Name = L"aOIDisplayToolStripMenuItem";
			this->aOIDisplayToolStripMenuItem->Size = System::Drawing::Size(231, 28);
			this->aOIDisplayToolStripMenuItem->Text = L"AOI Display";
			// 
			// flightsStripsDisplayToolStripMenuItem
			// 
			this->flightsStripsDisplayToolStripMenuItem->Name = L"flightsStripsDisplayToolStripMenuItem";
			this->flightsStripsDisplayToolStripMenuItem->Size = System::Drawing::Size(231, 28);
			this->flightsStripsDisplayToolStripMenuItem->Text = L"Flights Strips Display";
			// 
			// flightLinesDisplayToolStripMenuItem
			// 
			this->flightLinesDisplayToolStripMenuItem->Name = L"flightLinesDisplayToolStripMenuItem";
			this->flightLinesDisplayToolStripMenuItem->Size = System::Drawing::Size(231, 28);
			this->flightLinesDisplayToolStripMenuItem->Text = L"Flight Lines Display";
			// 
			// flightLinesTabulateedWindowToolStripMenuItem
			// 
			this->flightLinesTabulateedWindowToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(6) {this->flightLineNoToolStripMenuItem, 
				this->leftEndNameToolStripMenuItem, this->rightEndNameToolStripMenuItem, this->leftEndCoordinatesToolStripMenuItem, this->rightEndCoordinatesToolStripMenuItem, 
				this->turningFromToToolStripMenuItem});
			this->flightLinesTabulateedWindowToolStripMenuItem->Name = L"flightLinesTabulateedWindowToolStripMenuItem";
			this->flightLinesTabulateedWindowToolStripMenuItem->Size = System::Drawing::Size(324, 28);
			this->flightLinesTabulateedWindowToolStripMenuItem->Text = L"Flight Lines (Tabulateed Window)";
			// 
			// flightLineNoToolStripMenuItem
			// 
			this->flightLineNoToolStripMenuItem->Name = L"flightLineNoToolStripMenuItem";
			this->flightLineNoToolStripMenuItem->Size = System::Drawing::Size(280, 28);
			this->flightLineNoToolStripMenuItem->Text = L"Flight Line No";
			// 
			// leftEndNameToolStripMenuItem
			// 
			this->leftEndNameToolStripMenuItem->Name = L"leftEndNameToolStripMenuItem";
			this->leftEndNameToolStripMenuItem->Size = System::Drawing::Size(280, 28);
			this->leftEndNameToolStripMenuItem->Text = L"Left End Name";
			// 
			// rightEndNameToolStripMenuItem
			// 
			this->rightEndNameToolStripMenuItem->Name = L"rightEndNameToolStripMenuItem";
			this->rightEndNameToolStripMenuItem->Size = System::Drawing::Size(280, 28);
			this->rightEndNameToolStripMenuItem->Text = L"Right End Name";
			// 
			// leftEndCoordinatesToolStripMenuItem
			// 
			this->leftEndCoordinatesToolStripMenuItem->Name = L"leftEndCoordinatesToolStripMenuItem";
			this->leftEndCoordinatesToolStripMenuItem->Size = System::Drawing::Size(280, 28);
			this->leftEndCoordinatesToolStripMenuItem->Text = L"Left End Coordinates (x,y)";
			// 
			// rightEndCoordinatesToolStripMenuItem
			// 
			this->rightEndCoordinatesToolStripMenuItem->Name = L"rightEndCoordinatesToolStripMenuItem";
			this->rightEndCoordinatesToolStripMenuItem->Size = System::Drawing::Size(280, 28);
			this->rightEndCoordinatesToolStripMenuItem->Text = L"Right End Coordinates (x,y)";
			// 
			// turningFromToToolStripMenuItem
			// 
			this->turningFromToToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->editToolStripMenuItem});
			this->turningFromToToolStripMenuItem->Name = L"turningFromToToolStripMenuItem";
			this->turningFromToToolStripMenuItem->Size = System::Drawing::Size(280, 28);
			this->turningFromToToolStripMenuItem->Text = L"Turning From-To";
			// 
			// editToolStripMenuItem
			// 
			this->editToolStripMenuItem->Name = L"editToolStripMenuItem";
			this->editToolStripMenuItem->Size = System::Drawing::Size(108, 28);
			this->editToolStripMenuItem->Text = L"Edit";
			// 
			// detailsOpenAnotherWindowToolStripMenuItem
			// 
			this->detailsOpenAnotherWindowToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->spacingBeToolStripMenuItem, 
				this->swathBToolStripMenuItem, this->overlapetaToolStripMenuItem});
			this->detailsOpenAnotherWindowToolStripMenuItem->Name = L"detailsOpenAnotherWindowToolStripMenuItem";
			this->detailsOpenAnotherWindowToolStripMenuItem->Size = System::Drawing::Size(324, 28);
			this->detailsOpenAnotherWindowToolStripMenuItem->Text = L"Details (Open Another Window)";
			// 
			// spacingBeToolStripMenuItem
			// 
			this->spacingBeToolStripMenuItem->Name = L"spacingBeToolStripMenuItem";
			this->spacingBeToolStripMenuItem->Size = System::Drawing::Size(177, 28);
			this->spacingBeToolStripMenuItem->Text = L"Spacing (Be)";
			// 
			// swathBToolStripMenuItem
			// 
			this->swathBToolStripMenuItem->Name = L"swathBToolStripMenuItem";
			this->swathBToolStripMenuItem->Size = System::Drawing::Size(177, 28);
			this->swathBToolStripMenuItem->Text = L"Swath (B)";
			// 
			// overlapetaToolStripMenuItem
			// 
			this->overlapetaToolStripMenuItem->Name = L"overlapetaToolStripMenuItem";
			this->overlapetaToolStripMenuItem->Size = System::Drawing::Size(177, 28);
			this->overlapetaToolStripMenuItem->Text = L"Overlap (eta)";
			// 
			// runToolStripMenuItem
			// 
			this->runToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->designFlightPlanToolStripMenuItem, 
				this->designSessionPlanToolStripMenuItem, this->reDesignSessionToolStripMenuItem});
			this->runToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Segoe UI Semilight", 10.2F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->runToolStripMenuItem->Name = L"runToolStripMenuItem";
			this->runToolStripMenuItem->Padding = System::Windows::Forms::Padding(6, 4, 6, 0);
			this->runToolStripMenuItem->Size = System::Drawing::Size(54, 31);
			this->runToolStripMenuItem->Text = L"Run";
			// 
			// designFlightPlanToolStripMenuItem
			// 
			this->designFlightPlanToolStripMenuItem->Name = L"designFlightPlanToolStripMenuItem";
			this->designFlightPlanToolStripMenuItem->Size = System::Drawing::Size(227, 28);
			this->designFlightPlanToolStripMenuItem->Text = L"Design Flight Plan";
			// 
			// designSessionPlanToolStripMenuItem
			// 
			this->designSessionPlanToolStripMenuItem->Name = L"designSessionPlanToolStripMenuItem";
			this->designSessionPlanToolStripMenuItem->Size = System::Drawing::Size(227, 28);
			this->designSessionPlanToolStripMenuItem->Text = L"Design Session Plan";
			// 
			// reDesignSessionToolStripMenuItem
			// 
			this->reDesignSessionToolStripMenuItem->Name = L"reDesignSessionToolStripMenuItem";
			this->reDesignSessionToolStripMenuItem->Size = System::Drawing::Size(227, 28);
			this->reDesignSessionToolStripMenuItem->Text = L"Re-Design Session";
			// 
			// updateToolStripMenuItem
			// 
			this->updateToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->reDesignSessionsToolStripMenuItem});
			this->updateToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Segoe UI Semilight", 10.2F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->updateToolStripMenuItem->Name = L"updateToolStripMenuItem";
			this->updateToolStripMenuItem->Padding = System::Windows::Forms::Padding(6, 4, 6, 0);
			this->updateToolStripMenuItem->Size = System::Drawing::Size(80, 31);
			this->updateToolStripMenuItem->Text = L"Update";
			// 
			// reDesignSessionsToolStripMenuItem
			// 
			this->reDesignSessionsToolStripMenuItem->Name = L"reDesignSessionsToolStripMenuItem";
			this->reDesignSessionsToolStripMenuItem->Size = System::Drawing::Size(224, 28);
			this->reDesignSessionsToolStripMenuItem->Text = L"Re-Design Sessions";
			// 
			// reportToolStripMenuItem
			// 
			this->reportToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(5) {this->dispalyInitialReportToolStripMenuItem, 
				this->displayFinalReportToolStripMenuItem, this->allReportsInHTMLToolStripMenuItem, this->formatsWithPrintToolStripMenuItem, 
				this->optionsToolStripMenuItem});
			this->reportToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Segoe UI Semilight", 10.2F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->reportToolStripMenuItem->Name = L"reportToolStripMenuItem";
			this->reportToolStripMenuItem->Padding = System::Windows::Forms::Padding(6, 4, 6, 0);
			this->reportToolStripMenuItem->Size = System::Drawing::Size(83, 31);
			this->reportToolStripMenuItem->Text = L"Reports";
			// 
			// dispalyInitialReportToolStripMenuItem
			// 
			this->dispalyInitialReportToolStripMenuItem->Name = L"dispalyInitialReportToolStripMenuItem";
			this->dispalyInitialReportToolStripMenuItem->Size = System::Drawing::Size(233, 28);
			this->dispalyInitialReportToolStripMenuItem->Text = L"Dispaly Initial Report";
			// 
			// displayFinalReportToolStripMenuItem
			// 
			this->displayFinalReportToolStripMenuItem->Name = L"displayFinalReportToolStripMenuItem";
			this->displayFinalReportToolStripMenuItem->Size = System::Drawing::Size(233, 28);
			this->displayFinalReportToolStripMenuItem->Text = L"Display Final Report";
			// 
			// allReportsInHTMLToolStripMenuItem
			// 
			this->allReportsInHTMLToolStripMenuItem->Name = L"allReportsInHTMLToolStripMenuItem";
			this->allReportsInHTMLToolStripMenuItem->Size = System::Drawing::Size(233, 28);
			this->allReportsInHTMLToolStripMenuItem->Text = L"All Reports in HTML";
			// 
			// formatsWithPrintToolStripMenuItem
			// 
			this->formatsWithPrintToolStripMenuItem->Name = L"formatsWithPrintToolStripMenuItem";
			this->formatsWithPrintToolStripMenuItem->Size = System::Drawing::Size(233, 28);
			this->formatsWithPrintToolStripMenuItem->Text = L"Formats with Print";
			// 
			// optionsToolStripMenuItem
			// 
			this->optionsToolStripMenuItem->Name = L"optionsToolStripMenuItem";
			this->optionsToolStripMenuItem->Size = System::Drawing::Size(233, 28);
			this->optionsToolStripMenuItem->Text = L"Options";
			// 
			// helpToolStripMenuItem
			// 
			this->helpToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->helpHTMLToolStripMenuItem, 
				this->helpPDFToolStripMenuItem, this->activateLicenseToolStripMenuItem});
			this->helpToolStripMenuItem->Font = (gcnew System::Drawing::Font(L"Segoe UI Semilight", 10.2F, System::Drawing::FontStyle::Regular, 
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->helpToolStripMenuItem->Name = L"helpToolStripMenuItem";
			this->helpToolStripMenuItem->Padding = System::Windows::Forms::Padding(6, 4, 6, 0);
			this->helpToolStripMenuItem->Size = System::Drawing::Size(61, 31);
			this->helpToolStripMenuItem->Text = L"Help";
			// 
			// helpHTMLToolStripMenuItem
			// 
			this->helpHTMLToolStripMenuItem->Name = L"helpHTMLToolStripMenuItem";
			this->helpHTMLToolStripMenuItem->Size = System::Drawing::Size(198, 28);
			this->helpHTMLToolStripMenuItem->Text = L"Help (HTML)";
			// 
			// helpPDFToolStripMenuItem
			// 
			this->helpPDFToolStripMenuItem->Name = L"helpPDFToolStripMenuItem";
			this->helpPDFToolStripMenuItem->Size = System::Drawing::Size(198, 28);
			this->helpPDFToolStripMenuItem->Text = L"Help (PDF)";
			// 
			// activateLicenseToolStripMenuItem
			// 
			this->activateLicenseToolStripMenuItem->Name = L"activateLicenseToolStripMenuItem";
			this->activateLicenseToolStripMenuItem->Size = System::Drawing::Size(198, 28);
			this->activateLicenseToolStripMenuItem->Text = L"Activate License";
			// 
			// toolStrip1
			// 
			this->toolStrip1->AutoSize = false;
			this->toolStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(12) {this->toolStripButton1, 
				this->toolStripSeparator1, this->toolStripButton2, this->toolStripButton3, this->toolStripButton4, this->toolStripButton5, this->toolStripComboBox1, 
				this->toolStripButton6, this->toolStripComboBox2, this->toolStripButton7, this->toolStripComboBox3, this->toolStripButton8});
			this->toolStrip1->Location = System::Drawing::Point(0, 35);
			this->toolStrip1->Name = L"toolStrip1";
			this->toolStrip1->Size = System::Drawing::Size(1282, 40);
			this->toolStrip1->TabIndex = 1;
			this->toolStrip1->Text = L"toolStrip1";
			// 
			// toolStripButton1
			// 
			this->toolStripButton1->AutoSize = false;
			this->toolStripButton1->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
			this->toolStripButton1->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButton1.Image")));
			this->toolStripButton1->ImageTransparentColor = System::Drawing::Color::Magenta;
			this->toolStripButton1->Name = L"toolStripButton1";
			this->toolStripButton1->Size = System::Drawing::Size(33, 42);
			this->toolStripButton1->Text = L"toolStripButton1";
			this->toolStripButton1->ToolTipText = L"New Project";
			// 
			// toolStripSeparator1
			// 
			this->toolStripSeparator1->Name = L"toolStripSeparator1";
			this->toolStripSeparator1->Size = System::Drawing::Size(6, 40);
			// 
			// toolStripButton2
			// 
			this->toolStripButton2->AutoSize = false;
			this->toolStripButton2->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
			this->toolStripButton2->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButton2.Image")));
			this->toolStripButton2->ImageTransparentColor = System::Drawing::Color::Magenta;
			this->toolStripButton2->Name = L"toolStripButton2";
			this->toolStripButton2->Size = System::Drawing::Size(33, 42);
			this->toolStripButton2->Text = L"toolStripButton2";
			this->toolStripButton2->ToolTipText = L"Open Project";
			// 
			// toolStripButton3
			// 
			this->toolStripButton3->AutoSize = false;
			this->toolStripButton3->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
			this->toolStripButton3->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButton3.Image")));
			this->toolStripButton3->ImageTransparentColor = System::Drawing::Color::Magenta;
			this->toolStripButton3->Name = L"toolStripButton3";
			this->toolStripButton3->Size = System::Drawing::Size(33, 42);
			this->toolStripButton3->Text = L"toolStripButton3";
			this->toolStripButton3->ToolTipText = L"save";
			// 
			// toolStripButton4
			// 
			this->toolStripButton4->AutoSize = false;
			this->toolStripButton4->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
			this->toolStripButton4->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButton4.Image")));
			this->toolStripButton4->ImageTransparentColor = System::Drawing::Color::Magenta;
			this->toolStripButton4->Name = L"toolStripButton4";
			this->toolStripButton4->Size = System::Drawing::Size(33, 42);
			this->toolStripButton4->Text = L"toolStripButton4";
			this->toolStripButton4->ToolTipText = L"saveall";
			// 
			// toolStripButton5
			// 
			this->toolStripButton5->AutoSize = false;
			this->toolStripButton5->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
			this->toolStripButton5->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButton5.Image")));
			this->toolStripButton5->ImageTransparentColor = System::Drawing::Color::Magenta;
			this->toolStripButton5->Name = L"toolStripButton5";
			this->toolStripButton5->Size = System::Drawing::Size(33, 42);
			this->toolStripButton5->Text = L"toolStripButton5";
			this->toolStripButton5->ToolTipText = L"Open File";
			// 
			// toolStripComboBox1
			// 
			this->toolStripComboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(2) {L"DEM FILE", L"AOI FILE"});
			this->toolStripComboBox1->Name = L"toolStripComboBox1";
			this->toolStripComboBox1->Size = System::Drawing::Size(121, 40);
			this->toolStripComboBox1->Text = L"AOI FILE";
			// 
			// toolStripButton6
			// 
			this->toolStripButton6->AutoSize = false;
			this->toolStripButton6->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
			this->toolStripButton6->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButton6.Image")));
			this->toolStripButton6->ImageTransparentColor = System::Drawing::Color::Magenta;
			this->toolStripButton6->Name = L"toolStripButton6";
			this->toolStripButton6->Size = System::Drawing::Size(33, 42);
			this->toolStripButton6->Text = L"toolStripButton6";
			this->toolStripButton6->ToolTipText = L"Select Sensor";
			// 
			// toolStripComboBox2
			// 
			this->toolStripComboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(4) {L"GPS", L"IMU", L"LASER", L"CAMERA"});
			this->toolStripComboBox2->Name = L"toolStripComboBox2";
			this->toolStripComboBox2->Size = System::Drawing::Size(121, 40);
			this->toolStripComboBox2->Text = L"CAMERA";
			// 
			// toolStripButton7
			// 
			this->toolStripButton7->AutoSize = false;
			this->toolStripButton7->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
			this->toolStripButton7->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButton7.Image")));
			this->toolStripButton7->ImageTransparentColor = System::Drawing::Color::Magenta;
			this->toolStripButton7->Name = L"toolStripButton7";
			this->toolStripButton7->Size = System::Drawing::Size(23, 30);
			this->toolStripButton7->Text = L"toolStripButton7";
			this->toolStripButton7->ToolTipText = L"Run";
			// 
			// toolStripComboBox3
			// 
			this->toolStripComboBox3->AutoSize = false;
			this->toolStripComboBox3->Items->AddRange(gcnew cli::array< System::Object^  >(3) {L"Design Session Plan", L"Re-Design Session", 
				L"Design Flight Plan"});
			this->toolStripComboBox3->Name = L"toolStripComboBox3";
			this->toolStripComboBox3->Size = System::Drawing::Size(165, 28);
			this->toolStripComboBox3->Text = L"Design Flight Plan";
			// 
			// toolStripButton8
			// 
			this->toolStripButton8->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
			this->toolStripButton8->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"toolStripButton8.Image")));
			this->toolStripButton8->ImageTransparentColor = System::Drawing::Color::Magenta;
			this->toolStripButton8->Name = L"toolStripButton8";
			this->toolStripButton8->Size = System::Drawing::Size(23, 37);
			this->toolStripButton8->Text = L"toolStripButton8";
			this->toolStripButton8->ToolTipText = L"Help";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1282, 469);
			this->Controls->Add(this->toolStrip1);
			this->Controls->Add(this->menuStrip1);
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->Shown += gcnew System::EventHandler(this, &Form1::Form1_Shown);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->toolStrip1->ResumeLayout(false);
			this->toolStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void saveProjectWithNewNameToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 }

private: System::Void viewToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void preferencesToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void projectToolStripMenuItem_MouseHover(System::Object^  sender, System::EventArgs^  e) {
			// projectToolStripMenuItem->BackColor=Color::Blue;
		 }
private: System::Void projectToolStripMenuItem_MouseEnter(System::Object^  sender, System::EventArgs^  e) {
			// projectToolStripMenuItem->BackColor=Color::Blue;
		 }

private: System::Void projectToolStripMenuItem_MouseLeave(System::Object^  sender, System::EventArgs^  e) {
			 // projectToolStripMenuItem->BackColor=System::Drawing::SystemColors::InactiveCaption;
		 }
private: System::Void menuStrip1_MouseEnter(System::Object^  sender, System::EventArgs^  e) {
			 
		 }
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 
			
		 }
private: System::Void Form1_Shown(System::Object^  sender, System::EventArgs^  e) {
			 MessageBox::Show("You are using 3 days free version", "Warning",
			MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
			 dialogx^ f1 = gcnew dialogx("1");
			 f1->ShowDialog();
		 }
};
}

