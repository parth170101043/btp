#pragma once
#include<string>
#include <iostream>
#include <msclr/marshal_cppstd.h>

namespace draw_using_voice {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Drawing::Drawing2D;
	using namespace System::Speech::Synthesis;
	using namespace System::Speech::Recognition;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}

	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;

	private: System::Windows::Forms::ToolTip^  toolTip1;



























	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::Panel^  panel1;
	private: System::Windows::Forms::PictureBox^  pictureBox12;
	private: System::Windows::Forms::PictureBox^  pictureBox11;
	private: System::Windows::Forms::PictureBox^  pictureBox10;
	private: System::Windows::Forms::PictureBox^  pictureBox9;
	private: System::Windows::Forms::PictureBox^  pictureBox8;
	private: System::Windows::Forms::PictureBox^  pictureBox7;
	private: System::Windows::Forms::PictureBox^  pictureBox6;
	private: System::Windows::Forms::PictureBox^  pictureBox5;
	private: System::Windows::Forms::PictureBox^  pictureBox4;
	private: System::Windows::Forms::PictureBox^  pictureBox3;
	private: System::Windows::Forms::PictureBox^  pictureBox2;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  button1;
	private: System::ComponentModel::IContainer^  components;


	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->toolTip1 = (gcnew System::Windows::Forms::ToolTip(this->components));
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->pictureBox12 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox11 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox10 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox9 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox8 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox7 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox6 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox5 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox4 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox3 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->panel1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox12))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox11))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox10))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox9))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox8))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox7))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox6))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox5))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// comboBox1
			// 
			this->comboBox1->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(32, 396);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(275, 24);
			this->comboBox1->TabIndex = 1;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::comboBox1_SelectedIndexChanged);
			// 
			// label1
			// 
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 22.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(22, 25);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(1049, 51);
			this->label1->TabIndex = 2;
			this->label1->Text = L"USE DROPDOWNBOX ITEMS AS COMMANDS";
			// 
			// label2
			// 
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(27, 353);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(127, 23);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Draw Items";
			this->toolTip1->SetToolTip(this->label2, L"Vice Command:Draw Shapename");
			// 
			// label11
			// 
			this->label11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label11->Location = System::Drawing::Point(825, 160);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(152, 27);
			this->label11->TabIndex = 65;
			this->label11->Text = L"Pen Colour";
			this->toolTip1->SetToolTip(this->label11, L"voice command:Color Colorname");
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(1099, 44);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 72;
			this->button1->Text = L"Exit";
			this->toolTip1->SetToolTip(this->button1, L"Voice Command:Exit");
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// panel1
			// 
			this->panel1->Controls->Add(this->pictureBox12);
			this->panel1->Controls->Add(this->pictureBox11);
			this->panel1->Controls->Add(this->pictureBox10);
			this->panel1->Controls->Add(this->pictureBox9);
			this->panel1->Controls->Add(this->pictureBox8);
			this->panel1->Controls->Add(this->pictureBox7);
			this->panel1->Controls->Add(this->pictureBox6);
			this->panel1->Controls->Add(this->pictureBox5);
			this->panel1->Controls->Add(this->pictureBox4);
			this->panel1->Controls->Add(this->pictureBox3);
			this->panel1->Controls->Add(this->pictureBox2);
			this->panel1->Controls->Add(this->pictureBox1);
			this->panel1->Location = System::Drawing::Point(827, 204);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(309, 126);
			this->panel1->TabIndex = 69;
			// 
			// pictureBox12
			// 
			this->pictureBox12->BackColor = System::Drawing::Color::White;
			this->pictureBox12->Location = System::Drawing::Point(258, 59);
			this->pictureBox12->Name = L"pictureBox12";
			this->pictureBox12->Size = System::Drawing::Size(45, 50);
			this->pictureBox12->TabIndex = 22;
			this->pictureBox12->TabStop = false;
			this->pictureBox12->Click += gcnew System::EventHandler(this, &Form1::pictureBox12_Click);
			// 
			// pictureBox11
			// 
			this->pictureBox11->BackColor = System::Drawing::Color::Pink;
			this->pictureBox11->Location = System::Drawing::Point(207, 59);
			this->pictureBox11->Name = L"pictureBox11";
			this->pictureBox11->Size = System::Drawing::Size(45, 50);
			this->pictureBox11->TabIndex = 22;
			this->pictureBox11->TabStop = false;
			this->pictureBox11->Click += gcnew System::EventHandler(this, &Form1::pictureBox11_Click);
			// 
			// pictureBox10
			// 
			this->pictureBox10->BackColor = System::Drawing::Color::Green;
			this->pictureBox10->Location = System::Drawing::Point(156, 59);
			this->pictureBox10->Name = L"pictureBox10";
			this->pictureBox10->Size = System::Drawing::Size(45, 50);
			this->pictureBox10->TabIndex = 22;
			this->pictureBox10->TabStop = false;
			this->pictureBox10->Click += gcnew System::EventHandler(this, &Form1::pictureBox10_Click);
			// 
			// pictureBox9
			// 
			this->pictureBox9->BackColor = System::Drawing::Color::Navy;
			this->pictureBox9->Location = System::Drawing::Point(105, 59);
			this->pictureBox9->Name = L"pictureBox9";
			this->pictureBox9->Size = System::Drawing::Size(45, 50);
			this->pictureBox9->TabIndex = 29;
			this->pictureBox9->TabStop = false;
			this->pictureBox9->Click += gcnew System::EventHandler(this, &Form1::pictureBox9_Click);
			// 
			// pictureBox8
			// 
			this->pictureBox8->BackColor = System::Drawing::Color::Gray;
			this->pictureBox8->Location = System::Drawing::Point(54, 59);
			this->pictureBox8->Name = L"pictureBox8";
			this->pictureBox8->Size = System::Drawing::Size(45, 50);
			this->pictureBox8->TabIndex = 28;
			this->pictureBox8->TabStop = false;
			this->pictureBox8->Click += gcnew System::EventHandler(this, &Form1::pictureBox8_Click);
			// 
			// pictureBox7
			// 
			this->pictureBox7->BackColor = System::Drawing::Color::Lime;
			this->pictureBox7->Location = System::Drawing::Point(3, 59);
			this->pictureBox7->Name = L"pictureBox7";
			this->pictureBox7->Size = System::Drawing::Size(45, 50);
			this->pictureBox7->TabIndex = 27;
			this->pictureBox7->TabStop = false;
			this->pictureBox7->Click += gcnew System::EventHandler(this, &Form1::pictureBox7_Click);
			// 
			// pictureBox6
			// 
			this->pictureBox6->BackColor = System::Drawing::Color::Yellow;
			this->pictureBox6->Location = System::Drawing::Point(258, 3);
			this->pictureBox6->Name = L"pictureBox6";
			this->pictureBox6->Size = System::Drawing::Size(45, 50);
			this->pictureBox6->TabIndex = 26;
			this->pictureBox6->TabStop = false;
			this->pictureBox6->Click += gcnew System::EventHandler(this, &Form1::pictureBox6_Click);
			// 
			// pictureBox5
			// 
			this->pictureBox5->BackColor = System::Drawing::Color::Orange;
			this->pictureBox5->Location = System::Drawing::Point(207, 3);
			this->pictureBox5->Name = L"pictureBox5";
			this->pictureBox5->Size = System::Drawing::Size(45, 50);
			this->pictureBox5->TabIndex = 25;
			this->pictureBox5->TabStop = false;
			this->pictureBox5->Click += gcnew System::EventHandler(this, &Form1::pictureBox5_Click);
			// 
			// pictureBox4
			// 
			this->pictureBox4->BackColor = System::Drawing::Color::Red;
			this->pictureBox4->Location = System::Drawing::Point(156, 3);
			this->pictureBox4->Name = L"pictureBox4";
			this->pictureBox4->Size = System::Drawing::Size(45, 50);
			this->pictureBox4->TabIndex = 24;
			this->pictureBox4->TabStop = false;
			this->pictureBox4->Click += gcnew System::EventHandler(this, &Form1::pictureBox4_Click);
			// 
			// pictureBox3
			// 
			this->pictureBox3->BackColor = System::Drawing::Color::Brown;
			this->pictureBox3->Location = System::Drawing::Point(105, 3);
			this->pictureBox3->Name = L"pictureBox3";
			this->pictureBox3->Size = System::Drawing::Size(45, 50);
			this->pictureBox3->TabIndex = 23;
			this->pictureBox3->TabStop = false;
			this->pictureBox3->Click += gcnew System::EventHandler(this, &Form1::pictureBox3_Click);
			// 
			// pictureBox2
			// 
			this->pictureBox2->BackColor = System::Drawing::Color::Purple;
			this->pictureBox2->Location = System::Drawing::Point(54, 3);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(45, 50);
			this->pictureBox2->TabIndex = 22;
			this->pictureBox2->TabStop = false;
			this->pictureBox2->Click += gcnew System::EventHandler(this, &Form1::pictureBox2_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->pictureBox1->Location = System::Drawing::Point(3, 3);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(45, 50);
			this->pictureBox1->TabIndex = 21;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Click += gcnew System::EventHandler(this, &Form1::pictureBox1_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(932, 426);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(182, 22);
			this->textBox1->TabIndex = 70;
			// 
			// label3
			// 
			this->label3->Location = System::Drawing::Point(761, 426);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(165, 23);
			this->label3->TabIndex = 71;
			this->label3->Text = L"Voice Reconized";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1195, 637);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->panel1);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->comboBox1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &Form1::Form1_Paint);
			this->panel1->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox12))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox11))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox10))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox9))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox8))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox7))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox6))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox5))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}

	private:
		Graphics^ pg;
		Pen^ pen1;
		SolidBrush^ sb1;
		SpeechSynthesizer^ synth;
		SpeechRecognitionEngine^ recognizer ;
		 
		 #pragma endregion
	/*private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
						comboBox1->SelectedIndex = comboBox1->FindStringExact("Draw Rectangle");	 
			 }*/
	private: std::string conver(System::String^ s)
			 {
				 return msclr::interop::marshal_as< std::string >( s);
			 }
	private: System::Void speechInitialized()
			 {
				 synth=gcnew SpeechSynthesizer();
				recognizer=gcnew SpeechRecognitionEngine();
				//std::string circlest = "Draw ";
				  // cout << str << endl;
				std::string write="write";
				 //  String^ strcircle = gcnew String(circlest.c_str());
				   std::string drawCircle="Draw Circle";
				   String^ writestr=gcnew String(write.c_str());
				    String^ strCircle = gcnew String(drawCircle.c_str());
					std::string drawRectangle="Draw Rectangle";
					String^ strRectangle=gcnew String(drawRectangle.c_str());
					std::string drawTriangle="Draw Triangle";
					String^ strTriangle=gcnew String(drawTriangle.c_str());

					std::string exit="Exit";
					String^ strexit=gcnew String(exit.c_str());
				 // SpeechRecognitionEngine^ recognizer=gcnew SpeechRecognitionEngine();
				/*Grammar^ testGrammar = gcnew Grammar(gcnew GrammarBuilder(str2));*/
				Grammar^ circleGrammar= gcnew Grammar(gcnew GrammarBuilder(strCircle));
				Grammar^ rectangleGrammar= gcnew Grammar(gcnew GrammarBuilder(strRectangle));
				Grammar^ writeGrammar= gcnew Grammar(gcnew GrammarBuilder(writestr));
				Grammar^ triangleGrammar= gcnew Grammar(gcnew GrammarBuilder(strTriangle));
				Grammar^ exitGrammar= gcnew Grammar(gcnew GrammarBuilder(strexit));
				//recognizer->LoadGrammar(testGrammar);
				//Grammar^ dictationGrammar=gcnew DictationGrammar();
				//recognizer->LoadGrammar(dictationGrammar);
				loadgrammar();
				recognizer->LoadGrammar(circleGrammar);
				recognizer->LoadGrammar(rectangleGrammar);
				recognizer->LoadGrammar(writeGrammar);
				recognizer->LoadGrammar(triangleGrammar);
				recognizer->LoadGrammar(exitGrammar);

				recognizer->SetInputToDefaultAudioDevice();
						//synth->Speak("hh");
				recognizer->RecognizeAsync(RecognizeMode::Multiple);
				recognizer->SpeechRecognized+=gcnew System::EventHandler<SpeechRecognizedEventArgs ^>(this, &Form1::GetSpeech);
		
			 }
	private: System::Void loadgrammar()
			 {
										
						std::string Black="Color Black";
						String^ Blackste=gcnew String(Black.c_str());
						Grammar^ BlackGrammar=gcnew Grammar(gcnew GrammarBuilder(Blackste));
						recognizer->LoadGrammar(BlackGrammar);
						std::string Purple="Color Purple";
						String^ Purpleste=gcnew String(Purple.c_str());
						Grammar^ PurpleGrammar=gcnew Grammar(gcnew GrammarBuilder(Purpleste));
						recognizer->LoadGrammar(PurpleGrammar);
						std::string Brown="Color Brown";
						String^ Brownste=gcnew String(Brown.c_str());
						Grammar^ BrownGrammar=gcnew Grammar(gcnew GrammarBuilder(Brownste));
						recognizer->LoadGrammar(BrownGrammar);
						std::string Red="Color Red";
						String^ Redste=gcnew String(Red.c_str());
						Grammar^ RedGrammar=gcnew Grammar(gcnew GrammarBuilder(Redste));
						recognizer->LoadGrammar(RedGrammar);
						std::string Orange="Color Orange";
						String^ Orangeste=gcnew String(Orange.c_str());
						Grammar^ OrangeGrammar=gcnew Grammar(gcnew GrammarBuilder(Orangeste));
						recognizer->LoadGrammar(OrangeGrammar);
						std::string Yellow="Color Yellow";
						String^ Yellowste=gcnew String(Yellow.c_str());
						Grammar^ YellowGrammar=gcnew Grammar(gcnew GrammarBuilder(Yellowste));
						recognizer->LoadGrammar(YellowGrammar);
						std::string Lime="Color Lime";
						String^ Limeste=gcnew String(Lime.c_str());
						Grammar^ LimeGrammar=gcnew Grammar(gcnew GrammarBuilder(Limeste));
						recognizer->LoadGrammar(LimeGrammar);
						std::string Gray="Color Gray";
						String^ Grayste=gcnew String(Gray.c_str());
						Grammar^ GrayGrammar=gcnew Grammar(gcnew GrammarBuilder(Grayste));
						recognizer->LoadGrammar(GrayGrammar);
						std::string Blue="Color Blue";
						String^ Blueste=gcnew String(Blue.c_str());
						Grammar^ BlueGrammar=gcnew Grammar(gcnew GrammarBuilder(Blueste));
						recognizer->LoadGrammar(BlueGrammar);
						std::string Green="Color Green";
						String^ Greenste=gcnew String(Green.c_str());
						Grammar^ GreenGrammar=gcnew Grammar(gcnew GrammarBuilder(Greenste));
						recognizer->LoadGrammar(GreenGrammar);
						std::string Pink="Color Pink";
						String^ Pinkste=gcnew String(Pink.c_str());
						Grammar^ PinkGrammar=gcnew Grammar(gcnew GrammarBuilder(Pinkste));
						recognizer->LoadGrammar(PinkGrammar);
						std::string White="Color White";
						String^ Whiteste=gcnew String(White.c_str());
						Grammar^ WhiteGrammar=gcnew Grammar(gcnew GrammarBuilder(Whiteste));
						recognizer->LoadGrammar(WhiteGrammar);
			 }
	private: System::Void GetSpeech(System::Object^ sender, SpeechRecognizedEventArgs^ e)  
         {  
             textBox1->Text= e->Result->Text;  
			
			 std::string colorstr=conver(e->Result->Text);
					if(colorstr=="Exit")
						Application::Exit();

					if(colorstr=="Color Black")
					{
						pen1->Color=Color::Black;
						return;
					}
					if(colorstr=="Color Purple")
					{
						pen1->Color=Color::Purple;
						return;
					}
					if(colorstr=="Color Brown")
					{
						pen1->Color=Color::Brown;
						return;
					}
					if(colorstr=="Color Red")
					{
						pen1->Color=Color::Red;
						return;
					}
					if(colorstr=="Color Orange")
					{
						pen1->Color=Color::Orange;
						return;
					}
					if(colorstr=="Color Yellow")
					{
						pen1->Color=Color::Yellow;
						return;
					}
					if(colorstr=="Color Lime")
					{
						pen1->Color=Color::Lime;
						return;
					}
					if(colorstr=="Color Gray")
					{
						pen1->Color=Color::Gray;
						return;
					}
					if(colorstr=="Color Blue")
					{
						pen1->Color=Color::Blue;
						return;
					}
					if(colorstr=="Color Green")
					{
						pen1->Color=Color::Green;
						return;
					}
					if(colorstr=="Color Pink")
					{
						pen1->Color=Color::Pink;
						return;
					}
					if(colorstr=="Color White")
					{
						pen1->Color=Color::White;
						return;
					}
					 comboBox1->SelectedIndex = comboBox1->FindStringExact(e->Result->Text);

         } 
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 pg = CreateGraphics();
			 //rectanglestr="Draw Rectangle";
			 //circlestr="Draw Circle";
			
			 pen1 = gcnew Pen(Color::Red);
			 sb1 = gcnew SolidBrush(Color::White);
			 comboBox1->Items->Add("Draw Rectangle");
			  comboBox1->Items->Add("Draw Circle");
			   comboBox1->Items->Add("Draw Triangle");

			  speechInitialized();
			 // drawItem();
			 }
	private: System::Void comboBox1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
				 Invalidate();
				  
			
			 }
	private: System:: Void drawItem()
			 {
				 std::string myst;
				 myst="Draw Rectangle";
				// Invalidate();
				// pg->Clear();
				 if(myst==conver(comboBox1->Text))
				 {
					  pg->FillRectangle(sb1, 200, 70, 200, 100);

						pg->DrawRectangle(pen1, 200, 70, 200, 100);
						//synth->Speak("Rectangle Drawn");
						return ;
				 }
				 myst="Draw Circle";
				 if(myst==conver(comboBox1->Text))
				 {
					   pg->FillEllipse(sb1, 200,70, 90, 90);
					    pg->DrawEllipse(pen1, 200,70, 90, 90);
						//synth->Speak("Circle Drawn");
						return ;
				 }
				 myst="Draw Triangle";
				  if(myst==conver(comboBox1->Text))
				 {
					 Point pt1 = Point(300, 70);
					 Point pt2=Point(400,150);
					Point pt3 = Point(100, 150);
					 array<Point>^ p2 = { pt1, pt2, pt3 };
					pg->DrawPolygon(pen1, p2);
							 pg->FillPolygon(sb1, p2); 
							 //synth->Speak("Triangle Drawn");
						return ;
				 }

			 }
			 
	/*private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			Invalidate();
			 }*/
private: System::Void Form1_Paint(System::Object^  sender, System::Windows::Forms::PaintEventArgs^  e) {
			 drawItem();

		 }

private: System::Void pictureBox1_Click(System::Object^  sender, System::EventArgs^  e) {
		
		 pen1->Color = Color::Black;}
private: System::Void pictureBox2_Click(System::Object^  sender, System::EventArgs^  e) {
		  pen1->Color = Color::Purple;
		 }
private: System::Void pictureBox3_Click(System::Object^  sender, System::EventArgs^  e) {
		 pen1->Color = Color::Brown;
		 }
private: System::Void pictureBox4_Click(System::Object^  sender, System::EventArgs^  e) {
		 pen1->Color = Color::Red;
		 }
private: System::Void pictureBox5_Click(System::Object^  sender, System::EventArgs^  e) {
		  pen1->Color = Color::Orange;
		 }
private: System::Void pictureBox6_Click(System::Object^  sender, System::EventArgs^  e) {
		 pen1->Color = Color::Yellow;
		 }
private: System::Void pictureBox7_Click(System::Object^  sender, System::EventArgs^  e) {
		 pen1->Color = Color::Lime;
		 }
private: System::Void pictureBox8_Click(System::Object^  sender, System::EventArgs^  e) {
		  pen1->Color = Color::Gray;
		 }
private: System::Void pictureBox9_Click(System::Object^  sender, System::EventArgs^  e) {
		pen1->Color = Color::Blue;
		 }
private: System::Void pictureBox10_Click(System::Object^  sender, System::EventArgs^  e) {
		  pen1->Color = Color::Green;
		 }
private: System::Void pictureBox11_Click(System::Object^  sender, System::EventArgs^  e) {
		pen1->Color = Color::Pink;
		 }
private: System::Void pictureBox12_Click(System::Object^  sender, System::EventArgs^  e) {
		 pen1->Color = Color::White;
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 Application::Exit();
		 }
};
}

