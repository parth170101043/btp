#pragma once
#include "form2.h"
#include "cstdlib"
#include <string>
#using <mscorlib.dll>
#using <System.xml.dll>
#include <utility> 
#include <fstream>
#include <string>
#include <msclr/marshal.h>
//#include <atlstr.h>
#include <stdio.h>
#include <msclr/marshal_cppstd.h>
namespace openMap {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::WebBrowser^  webBrowser1;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->webBrowser1 = (gcnew System::Windows::Forms::WebBrowser());
			this->SuspendLayout();
			// 
			// webBrowser1
			// 
			this->webBrowser1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->webBrowser1->Location = System::Drawing::Point(0, 0);
			this->webBrowser1->MinimumSize = System::Drawing::Size(20, 20);
			this->webBrowser1->Name = L"webBrowser1";
			this->webBrowser1->Size = System::Drawing::Size(324, 296);
			this->webBrowser1->TabIndex = 0;
			this->webBrowser1->DocumentCompleted += gcnew System::Windows::Forms::WebBrowserDocumentCompletedEventHandler(this, &Form1::webBrowser1_DocumentCompleted);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(324, 296);
			this->Controls->Add(this->webBrowser1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->WindowState = System::Windows::Forms::FormWindowState::Maximized;
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
				// FixBrowserEmulation();
			 Stream^ myStream;
			//webBrowser1->ScriptErrorsSuppressed = true;
			webBrowser1->Visible=true;
			/********/
			//webBrowser1->ScriptErrorsSuppressed = false;
			/*OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;

			  if(openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK )
				 { if( (myStream = openFileDialog1 -> OpenFile()) != nullptr )
				   {
					String^ strfilename = openFileDialog1 -> InitialDirectory + openFileDialog1 -> FileName;
					  MessageBox::Show(strfilename);
					  char cNow[100] = { 0 };
						char line[200];
						for (int i = 0; i < strfilename->Length; i++)
							cNow[i] = static_cast<char>(strfilename[i]);
						FILE * file = fopen(cNow, "r");
						String^ strg="";
						while (fgets(line, sizeof(line), file))
						{
							strg +=  gcnew String(line);
						}
						MessageBox::Show(strg);
						//webBrowser1->DocumentText = strg;
			  }}*/
			/*String^ strfilename = Application::StartupPath + "\\ab.html";
			MessageBox::Show(strfilename);
		//webBrowser1->DocumentText = docfile;
		char cNow[100] = { 0 };
		char line[200];
		for (int i = 0; i < strfilename->Length; i++)
			cNow[i] = static_cast<char>(strfilename[i]);
		FILE * file = fopen(cNow, "r");
		//std::ifstream f(docfile.c_str()); //taking file as inputstream
		String^ strg="";
		//str += "hell";
		while (fgets(line, sizeof(line), file))
		{
			strg +=  gcnew String(line);
		}
		MessageBox::Show(strg);
		//webBrowser1->DocumentText = str;






			/********/
			//String^ docFile=
			 //webBrowser1->Navigate("https://www.google.com/maps");
			webBrowser1->Navigate("https://www.google.com/maps/@?api=1&map_action=map&parameters");
			 //https://www.google.com/maps/@?api=1&map_action=map&parameters

				 form2^ f2=gcnew form2();
				f2->ShowDialog();
			 }
	
	private: System::Void webBrowser1_DocumentCompleted(System::Object^  sender, System::Windows::Forms::WebBrowserDocumentCompletedEventArgs^  e) {
			 }
	};
}

