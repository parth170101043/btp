#pragma once
#include "cstdlib"
#include <string>
#using <mscorlib.dll>
#using <System.xml.dll>
#include <utility> 
#include <fstream>
#include <string>
#include <msclr/marshal.h>
//#include <atlstr.h>
#include <stdio.h>
#include <msclr/marshal_cppstd.h>
namespace openMap {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Drawing::Drawing2D;
	using namespace System::IO;
	using namespace System::Xml;
	using namespace System::Runtime::InteropServices;


	/// <summary>
	/// Summary for form2
	/// </summary>
	public ref class form2 : public System::Windows::Forms::Form
	{
	public:
		form2(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~form2()
		{
			if (components)
			{
				delete components;
			}
		}

	protected: 
	private: System::Windows::Forms::ToolStripMenuItem^  openStripesDaraToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  openKmlToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  openMapToolStripMenuItem;
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  closeMapToolStripMenuItem;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->openStripesDaraToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openKmlToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openMapToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->closeMapToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->menuStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// openStripesDaraToolStripMenuItem
			// 
			this->openStripesDaraToolStripMenuItem->Name = L"openStripesDaraToolStripMenuItem";
			this->openStripesDaraToolStripMenuItem->Size = System::Drawing::Size(199, 24);
			this->openStripesDaraToolStripMenuItem->Text = L"Open Stripes Dara";
			this->openStripesDaraToolStripMenuItem->Click += gcnew System::EventHandler(this, &form2::openStripesDaraToolStripMenuItem_Click);
			// 
			// openKmlToolStripMenuItem
			// 
			this->openKmlToolStripMenuItem->Name = L"openKmlToolStripMenuItem";
			this->openKmlToolStripMenuItem->Size = System::Drawing::Size(199, 24);
			this->openKmlToolStripMenuItem->Text = L"Open kml";
			this->openKmlToolStripMenuItem->Click += gcnew System::EventHandler(this, &form2::openKmlToolStripMenuItem_Click);
			// 
			// fileToolStripMenuItem
			// 
			this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->openKmlToolStripMenuItem, 
				this->openStripesDaraToolStripMenuItem, this->openMapToolStripMenuItem, this->closeMapToolStripMenuItem});
			this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
			this->fileToolStripMenuItem->Size = System::Drawing::Size(44, 24);
			this->fileToolStripMenuItem->Text = L"File";
			// 
			// openMapToolStripMenuItem
			// 
			this->openMapToolStripMenuItem->Name = L"openMapToolStripMenuItem";
			this->openMapToolStripMenuItem->Size = System::Drawing::Size(199, 24);
			this->openMapToolStripMenuItem->Text = L"Open Map";
			this->openMapToolStripMenuItem->Click += gcnew System::EventHandler(this, &form2::openMapToolStripMenuItem_Click);
			// 
			// closeMapToolStripMenuItem
			// 
			this->closeMapToolStripMenuItem->Name = L"closeMapToolStripMenuItem";
			this->closeMapToolStripMenuItem->Size = System::Drawing::Size(199, 24);
			this->closeMapToolStripMenuItem->Text = L"Close Map";
			this->closeMapToolStripMenuItem->Click += gcnew System::EventHandler(this, &form2::closeMapToolStripMenuItem_Click);
			// 
			// menuStrip1
			// 
			this->menuStrip1->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->fileToolStripMenuItem});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(282, 28);
			this->menuStrip1->TabIndex = 4;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// form2
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->Controls->Add(this->menuStrip1);
			this->Name = L"form2";
			this->Text = L"form2";
			this->WindowState = System::Windows::Forms::FormWindowState::Maximized;
			this->Load += gcnew System::EventHandler(this, &form2::form2_Load);
			this->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &form2::form2_Paint);
			this->Resize += gcnew System::EventHandler(this, &form2::form2_Resize);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
		private:
		
		int point_count;
		int x;
		int y;
		array<double>^ Arrx;
		array<double>^ Arry;
		array<double>^ Arrx1;
		array<double>^ Arry1;
		double xmax,xmin,ymax,ymin,xdiff,ydiff;
		Graphics^ pg;
		Pen^ pen1;
		array<Point>^ local;
		int formwidth,formheight;
		bool map;
		 Color _oldBG;
		 Color _oldTPKey;

#pragma endregion
	private: System::Void openKmlToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
//			 	webBrowser1->Visible=false;
				 Stream^ myStream;
				point_count=0;
				xmax=-180;
				 xmin=180;
				 ymax=-180;
				 ymin=180;
				 map=1;
				  
				 
			 OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;

			  if( openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK )
				 { if( (myStream = openFileDialog1 -> OpenFile()) != nullptr )
				   {
					  String^ strfilename = openFileDialog1 -> InitialDirectory + openFileDialog1 -> FileName;
					  MessageBox::Show(strfilename);
					   array<String^> ^StringNameArray =strfilename->Split('.');
					   if(StringNameArray[1]!="kml")
					   {
						   MessageBox::Show("Please Open a Kml File");
						   return;
					   }
					  myStream -> Close();
					  XmlTextReader^ reader = gcnew XmlTextReader (strfilename);
					  while (reader->Read()) 
					  {
						String^ s1="hello";
						switch (reader->NodeType) 
						{
							case XmlNodeType::Element: // The node is an element.
							s1=reader->Name;
							//Console::Write("{0} :", reader->Name);
							//Console::Write(s1);
							//Console::WriteLine(reader->Name);
			
							//Console::Write("{0} :", reader->Name);
							break;

							case XmlNodeType::Text: //Display the text in each element.
								/*String* s2 ;
								s2="longitude";
								Console::WriteLine(" {0}={1}", s1, s2);*/
								if(s1 == "coordinates"  )
								{
									Console::Write("{0} : ", s1);
									Console::Write("{0} ", reader->Value);
									Console::WriteLine ("");
									// textBox1->Text=reader->Value;

									 //double dub=Convert::ToDouble(reader->Value);
									  //MessageBox::Show(dub.ToString());
									  String^ str=reader->Value;
										array<String^> ^StringArray =str->Split(' ');
									  for each(String^ temp in StringArray)
									  {
					
										 // double dub=Convert::ToDouble(StringArray[0]);
										 // MessageBox::Show(dub.ToString());
										   //MessageBox::Show(temp);
										  if(temp[0]==' '||temp==""||temp[0]=='\t')
											  break;
										  if(sizeof(temp)==0)break;
										 // MessageBox::Show("kkk = *"+temp+"*");
										   array<String^> ^StringArray1 =temp->Split(',');
										    //MessageBox::Show("kkk = *"+StringArray1[0]+"*");
										   int count=0;
										   for each(String^ temp1 in StringArray1)
										   {
											   count++;
										   }
										   if(count<3)
											   break;
											double dub;
											//if(Convert::ToDouble(StringArray1[0])!=NULL)
										   dub=Convert::ToDouble(StringArray1[0]);
										   if(dub>xmax)
											   xmax=dub;
										   if(dub<xmin)
											   xmin=dub;
											Arrx[point_count]=dub;

											//MessageBox::Show(dub.ToString());
										   dub=Convert::ToDouble(StringArray1[1]);
											   if(dub>ymax)
												   ymax=dub;
											   if(dub<ymin)
												   ymin=dub;
												Arry[point_count]=dub;
											//MessageBox::Show(dub.ToString());
											point_count+=1;

									  }
								}
							
							break;
			

							}
						}
					  //
				 }
				 }
			 // local  = gcnew array<Point>(point_count);
			  Invalidate();
			  //drawmap();
			  
			 }
private: System::Void openStripesDaraToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		  Stream^ myStream;
				point_count=0;
				xmax=INT_MIN;
				 xmin=INT_MAX;
				 ymax=INT_MIN;
				 ymin=INT_MAX;
				 map=0;
				  
				 
			 OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;

			  if(openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK )
				 { if( (myStream = openFileDialog1 -> OpenFile()) != nullptr )
				   {
					String^ strfilename = openFileDialog1 -> InitialDirectory + openFileDialog1 -> FileName;
					  MessageBox::Show(strfilename);
					   array<String^> ^StringNameArray =strfilename->Split('.');
					   if(StringNameArray[1]!="txt")
					   {
						   MessageBox::Show("Please Open a txt File");
						   return;
					   }
					  // String^ word;
					  myStream -> Close();
					// CString str2(strfilename);
					  //FILE * file = fopen(str2,"r");
					  char line[100];
					  bool xy=1;
					  char cNow[100] = { 0 };
					  for (int i = 0; i < strfilename->Length; i++)
						cNow[i] = static_cast<char>(strfilename[i]);
					  FILE * file = fopen(cNow,"r");
					  double dub;
					  while (fgets(line, sizeof(line), file)) 
						{ 
							// displaying content 
							sscanf(line,"%lf",&dub);
							//String^ nn=gcnew String(line);;
							//MessageBox::Show(dub.ToString()); 
							if(xy)
							{
								if(dub>xmax)
								xmax=dub;
								if(dub<xmin)
								xmin=dub;
								Arrx[point_count]=dub;
								xy=!xy;
							}
							else
							{
								if(dub>ymax)
								ymax=dub;
								if(dub<ymin)
								ymin=dub;
								Arry[point_count]=dub;
											//MessageBox::Show(dub.ToString());
								point_count+=1;
								xy=!xy;
							}
							
						} 

					}
				   }
			   Invalidate();

		 }
private: System::Void openMapToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		// _oldBG=this->BackColor;
		 //_oldTPKey=this->TransparencyKey;
			
		 }
private: System::Void drawmap(){
			  xdiff=xmax-xmin;
			 ydiff=ymax-ymin;
		
			 //Graphics^ g = e->Graphics;
			 
			//  MessageBox::Show(point_count.ToString());
			 formwidth=(this->Width)-60;
			formheight=(this->Height)-130;
			//MessageBox::Show("xmin = "+xmin.ToString()+" xmax = "+xmax.ToString()+" ymin = "+ymin.ToString()+" ymax = "+ymax.ToString()+" xdiff = "+xdiff.ToString()+" ydiff = "+ydiff.ToString()+" width = "+formwidth+" height = "+formheight);
			//textBox1->Text=formwidth.ToString()+"X"+formheight.ToString();
			 for(int i=0;i<point_count;i++)
			 { double a=Arrx[i],b=Arry[i];
				 a-=xmin;
				 a*=formwidth;
				 a/=xdiff;
				 b-=ymin;
				 b*=formheight;
				 b/=ydiff;
				 int x=int(a)+20;
				 

				 int y=int(b)+80;
				
				//MessageBox::Show("x = "+x.ToString()+" y = "+y.ToString());
				local[i]=Point(x,y);
				pg->DrawEllipse(pen1, x-5,y-5, 10, 10);
				//MessageBox::Show(x.ToString()+" "+y.ToString());
			 }
			

				
			 
		 }
private: System::Void drawrect(){
			 xmax=abs(xmax)>abs(xmin)?abs(xmax):abs(xmin);
			 ymax=abs(ymax)>abs(ymin)?abs(ymax):abs(ymin);
			 formwidth=(this->Width)-60;
			formheight=(this->Height)-130;
			int xplus=INT_MIN,xminus=INT_MAX,yplus=INT_MIN,yminus=INT_MAX;
			int x,y;
			int* cox=new int[point_count];
			int* coy=new int[point_count];
			for(int i=0;i<point_count;i++)
			 { double a=Arrx[i],b=Arry[i];
				/* a-=xmin;
				 a*=formwidth;
				 a/=xdiff;
				 b-=ymin;
				 b*=formheight;
				 b/=ydiff;*/
					a=a*((0.5*formwidth)/xmax);
					b=b*((0.5*formheight)/ymax);
					
				
					x=int(0.5*formwidth+a);
					y=int(0.5*formheight-b);
					xplus=max(x,xplus);
					xminus=min(x,xminus);
					yplus=max(yplus,y);
					yminus=min(yminus,y);
					cox[i]=x;
					coy[i]=y;
					//x=int(formwidth+2*a)+20;
					//y=int(formheight-2*b)+80;
				//MessageBox::Show("x = "+x.ToString()+" y = "+y.ToString());
				
				//MessageBox::Show(x.ToString()+" "+y.ToString());
			 }
			xdiff=abs(xplus-xminus);
			ydiff=abs(yplus-yminus);
			//MessageBox::Show("xmin = "+xminus.ToString()+" xmax = "+xplus.ToString()+" ymin = "+yminus.ToString()+" ymax = "+yplus.ToString()+" xdiff = "+xdiff.ToString()+" ydiff = "+ydiff.ToString()+" width = "+formwidth+" height = "+formheight);
			
			for(int i=0;i<point_count;i++)
			{
				double a=cox[i];
				double b=coy[i];
				 a-=xminus;
				 a*=formwidth;
				 a/=xdiff;
				 b-=yminus;
				 b*=formheight;
				 b/=ydiff;
				 x=int(a)+20;
				 y=int(b)+80;
				 local[i]=Point(x,y);
				// MessageBox::Show(x.ToString()+" "+y.ToString());
				pg->DrawEllipse(pen1, x-5,y-5, 10, 10);

			}
			//pg->DrawEllipse(pen1, 0.5*formwidth+20,0.5*formheight+80, 10, 10);
		 }
private: System::Void form2_Load(System::Object^  sender, System::EventArgs^  e) {
			  pg = CreateGraphics();
			 pen1 = gcnew Pen(Color::Red);
			 //rectanglestr="Draw Rectangle";
			 //circlestr="Draw Circle";
			// pictureBox1->BringToFront();
			 //pg->BringToFront();
			// webBrowser1->BringToBack();
			  this->BackColor = Color::LimeGreen;
				this->TransparencyKey = Color::LimeGreen;
			formwidth=(this->Width)-40;
			formheight=(this->Height)-110;
			
				// Arrx=gcnew array<double>(200);
				// Arry=gcnew array<double>(200);
				 
				 x=-1;
				 y=-1;
				// textBox1->Text=(this->Width).ToString()+"   " +(this->Height).ToString()+point_count.ToString();
				 Arrx=gcnew array<double>(200);
				 Arry=gcnew array<double>(200);
				// xmax=-180;
				// xmin=180;
				// ymax=-180;
				// ymin=180;
				// drawmap();
				  
		 }
private: System::Void form2_Paint(System::Object^  sender, System::Windows::Forms::PaintEventArgs^  e) {
		  
			  if(point_count>0)
				{local  = gcnew array<Point>(point_count);
					
					if(map)
					{
						drawmap();
						pg->DrawPolygon(pen1, local);
					}
					else
					{drawrect();
						for(int i=0;i<point_count;i=i+2)
						{
							//MessageBox::Show("f");
							
							pg->DrawRectangle(pen1,local[i].X,local[i].Y,abs(abs(local[i+1].X)-abs(local[i].X)),abs(abs(local[i+1].Y)-abs(local[i].Y)));
						}
					}
				//	MessageBox::Show("xmin = "+xmin.ToString()+" xmax = "+xmax.ToString()+" ymin = "+ymin.ToString()+" ymax = "+ymax.ToString()+" xdiff = "+xdiff.ToString()+" ydiff = "+ydiff.ToString());
		
					//pg->DrawPolygon(pen1, local);
				}
		 }
private: System::Void form2_Resize(System::Object^  sender, System::EventArgs^  e) {
		Invalidate();
		 }
private: System::Void closeMapToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			
		 }
};
}
